/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;
//Menu là cái khuôn chuyên tạo menu
//cần tạo menu thì gọi khuôn ra đúc

import java.util.ArrayList;

public class Menu<E> {

    private String title;
    private ArrayList<String> optionList;

    //contructor
    public Menu(String title) {
        this.title = title;
        optionList = new ArrayList<>();
    }

    public void addNewOpt(String newOtp) {
        this.optionList.add(newOtp);
    }

    public void print() {
        System.out.println(this.title);
        int count = 1;
        for (String opt : optionList) {
            System.out.println(count + ". " + opt);
            count++;
        }
    }

    public int getChoice() {
        //mời nhập lựa chọn
        return Inputter.getAnInteger("Nhập lựa chọn của bạn: ", "Lựa chọn phải từ 1 đến " + this.optionList.size(), 1, this.optionList.size());

    }

    public E ref_getChoice(ArrayList<E> options) {
        //option mà cô nói tới là brandList
        //cô muốn in brandList như 1 menu để chọn brand
        //E là Brand
        for (int i = 0; i <= options.size() - 1; i++) {
            System.out.println((i + 1) + ". " + options.get(i).toString());
        }
        int choice = Inputter.getAnInteger("Input your choice: ", "Your choice must be between 1 and" + options.size(), 1, options.size());
        return options.get(choice - 1);
    }
    
}
