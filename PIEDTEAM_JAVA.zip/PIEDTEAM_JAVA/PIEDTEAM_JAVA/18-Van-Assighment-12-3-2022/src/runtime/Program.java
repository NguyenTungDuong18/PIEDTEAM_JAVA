package runtime;

import data.BrandList;
import data.CarList;
import util.Inputter;
import util.Menu;

public class Program {

    public static void main(String[] args) {
        //tạo Menu
        Menu mainMenu = new Menu("Minh Trang BWM ShowRoom Application");
        mainMenu.addNewOpt("List all brands");
        mainMenu.addNewOpt("Add a new brand");
        mainMenu.addNewOpt("Search a brand based on its ID");
        mainMenu.addNewOpt("Update a brand");
        mainMenu.addNewOpt("Save brands to the file, named brands.txt");
        mainMenu.addNewOpt("List all cars in ascending order of brand names");
        mainMenu.addNewOpt("List cars based on a part of an input brand name");
        mainMenu.addNewOpt("Add a car");
        mainMenu.addNewOpt("Remove a car based on its ID");
        mainMenu.addNewOpt("Update a car based on its ID");
        mainMenu.addNewOpt("Save cars to file, named cars.txt");
        
        
        String baseURL = "C:\\Users\\Admin\\OneDrive\\Desktop\\JAVA_LAB\\";
        BrandList bl = new BrandList();
        CarList cl = new CarList(bl);
        bl.loadFromFile(baseURL + "brands.txt");
        cl.loadFromFile(baseURL + "cars.txt");
        while (true) {
            //in menu
            mainMenu.print();//in MENU
            int choice = Inputter.getAnInteger("Input your choice: ", "choice is required");//xin lựa chọn
            //xử lý
            switch (choice) {
                case 1: {

                    bl.listBrands();
                    break;
                }
                case 2: {

                    bl.addBrand();
                    break;
                }
                case 3: {

                    bl.searchBrand();
                    break;
                }
                case 4: {

                    bl.updateBrand();
                    break;
                }
                case 5: {

                    bl.saveToFile(baseURL + "brands.txt");
                    break;
                }
                case 6: {

                    cl.listCars();
                    break;
                }
                case 7: {

                    cl.printBasedBrandName();
                    break;
                }
                case 8: {

                    cl.addCar();
                    break;
                }
                case 9: {

                    cl.removeCar();
                    break;
                }
                case 10: {

                    cl.updateCar();
                    break;
                }
                case 11: {

                    cl.saveToFile(baseURL + "cars.txt");
                    break;
                }
                default:{
                    System.out.println("See you again");
                    return;//thoát
                }
                //another case ....
            }
        }
    }

}
