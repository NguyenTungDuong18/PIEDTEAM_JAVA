package data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.StringTokenizer;
import sun.util.locale.StringTokenIterator;
import util.FileHandler;
import util.Inputter;

public class CarList extends ArrayList<Car> {

    private BrandList brandList;
    private FileHandler<Car> fh_car = new FileHandler<Car>() {
        @Override
        public Car handleLine(String line) {
            //line   C01, B7-2018, red, F12345, E12345
            //format ID, brand ID, color, frame ID, engine ID
            StringTokenizer st = new StringTokenizer(line, ",");
            String carID = st.nextToken().trim();
            String brandID = st.nextToken().trim();
            String color = st.nextToken().trim();
            String frameID = st.nextToken().trim();
            String engineID = st.nextToken().trim();
            //
            Brand brand = brandList.findBrandByBrandID(brandID);//biến branList thành brand
            Car car = new Car(carID, brand, color, frameID, engineID);
            return car;
        }

    };
    //contructor

    public CarList(BrandList brandList) {
        this.brandList = brandList;
    }

    //
    public boolean loadFromFile(String filename) {
        return fh_car.load(filename, this);
        //this là class chứa nó => CarList
    }

    //
    public boolean saveToFile(String filename) {
        return fh_car.save(this, filename);
    }

    public int searchID(String carID) {
        //this là CarList
        for (int i = 0; i <= this.size() - 1; i++) {
            if (this.get(i).getCarID().equals(carID)) {
                return i;
            }
        }
        //
        return -1;
    }

    public int searchFrame(String frameID) {

        for (int i = 0; i <= this.size() - 1; i++) {
            if (this.get(i).getFrameID().equals(frameID)) {
                return i;
            }
        }
        //
        return -1;
    }

    public int searchEngine(String engineID) {
        for (int i = 0; i <= this.size() - 1; i++) {
            if (this.get(i).getEngineID().equals(engineID)) {
                return i;
            }
        }
        //
        return -1;
    }

    public void addCar() {
        System.out.println("Add a new Car");
        String carID;
        while (true) {
            carID = Inputter.getAString("Input CarID", "CarID is required");// cấm trùng
            if (searchID(carID) != -1) {
                System.out.println("CarID has been used");

            } else {
                break;
            }
        }
        //brand
        Brand brand = brandList.getUserChoice();
        //color
        String color = Inputter.getAString("Input color", "Color is required");
        //frameID
        String frameID;
        while (true) {
            frameID = Inputter.getAString("Input frameID", "frameID is required", "^F\\d{5}$");// cấm trùng
            if (searchFrame(frameID) != -1) {
                System.out.println("frameID has been used");

            } else {
                break;
            }
        }
        //Engine
        String engineID;
        while (true) {
            engineID = Inputter.getAString("Input engineID", "engineID is required", "^E\\d{5}$");// cấm trùng
            if (searchEngine(engineID) != -1) {
                System.out.println("engineID has been used");

            } else {
                break;
            }
        }
        //Xin xong các prop cần để tạo Car
        Car newCar = new Car(carID, brand, color, frameID, engineID);
        this.add(newCar);// thêm newCar vào CarList
    }

    //
    public void printBasedBrandName() {
        String aPartOfBrandName = Inputter.getAString("Input aPartOfBrandName", "aPartOfBrandName is required");

        boolean isFind = false;
        for (Car car : this) {
            if (car.getBrand().getBrandName().contains(aPartOfBrandName)) {//di qua ds những chiếc sẽ nếu tên của cái hãng của cái hãng của cãi xe nào có cái tện hãng cần tìm thì show
                System.out.println(car.screenString());
            }
        }

        //tao có ! nha
        if (!isFind) {
            System.out.println("Nothinf to print");
        }
    }

    //
    public boolean removeCar() {
        System.out.println("Remove a Car");
        String carID = Inputter.getAString("Input CarID, you wanna delete:", "Car is required");
        int pos = searchID(carID);// == -1 || != -1
        if (pos == - 1) {
            System.out.println("Car doen't exist");
            return false;//Không tìm thấy thì nghỉ luôn
        }
        //con không tìm thấy thì xử lý
        System.out.println("Car Deleting is succesfully");
        this.remove(pos);//xóa có thể xóa bằng vị trí luôn
        return true;
    }

    public boolean updateCar() {
        System.out.println("update a Car");
        String carID = Inputter.getAString("Input CarID, you wanna update:", "Car is required");
        int pos = searchID(carID);// == -1 || != -1
        if (pos == - 1) {
            System.out.println("Car doen't exist");
            return false;//Không tìm thấy thì nghỉ luôn
        }
        //con không tìm thấy thì xử lý
        System.out.println("Car information before updating");
        System.out.println(this.get(pos).screenString());
        //xin thông tin cần update
        //brand
        Brand brand = brandList.getUserChoice();
        //color
        String color = Inputter.getAString("Input new color", "Color is required");
        //frameID
        String frameID;
        while (true) {
            frameID = Inputter.getAString("Input new frameID", "frameID is required", "^F\\d{5}$");// cấm trùng
            if (searchFrame(frameID) != -1) {
                System.out.println("frameID has been used");

            } else {
                break;
            }
        }
        //Engine
        String engineID;
        while (true) {
            engineID = Inputter.getAString("Input new engineID", "engineID is required", "^E\\d{5}$");// cấm trùng
            if (searchEngine(engineID) != -1) {
                System.out.println("engineID has been used");

            } else {
                break;
            }
        }
        //Xin xong thì set(set trực tiếp không qua update)
        this.get(pos).setBrand(brand);
        this.get(pos).setColor(color);
        this.get(pos).setEngineID(engineID);
        this.get(pos).setFrameID(frameID);
        System.out.println("Information of car after updating");
        System.out.println(this.get(pos).screenString());
        return true;
    }

    public void listCars() {
        System.out.println("List of cars");
        //this là carList và nó chứa car, mà car là comparable
        Collections.sort(this);
        for (Car car : this) {
            System.out.println(car.screenString());
        }
        //
        if (this.isEmpty()) {
            System.out.println("Nothing to print");
        }
    }
}
