package data;
//Nếu đọc file dùng dấu + public
//                      _ private
//                      # protected

public class Brand {

    private String brandID;
    private String brandName;
    private String soundBrand;
    private double price;
    //contructor

    public Brand() {//dùng cho oop
    }

    //Dùng cho đọc file
    public Brand(String brandID, String brandName, String soundBrand, double price) {
        this.brandID = brandID;
        this.brandName = brandName;
        this.soundBrand = soundBrand;
        this.price = price;
    }
    //getter và setter

    public String getBrandID() {
        return brandID;
    }

    public String getBrandName() {
        return brandName;
    }

    public String getSoundBrand() {
        return soundBrand;
    }

    public double getPrice() {
        return price;
    }

    public void setBrandID(String brandID) {
        this.brandID = brandID;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public void setSoundBrand(String soundBrand) {
        this.soundBrand = soundBrand;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    //

    @Override
    public String toString() {
        return String.format("%s,%s,%s : %5.3f", brandID, brandName, soundBrand, price);
    }

}
