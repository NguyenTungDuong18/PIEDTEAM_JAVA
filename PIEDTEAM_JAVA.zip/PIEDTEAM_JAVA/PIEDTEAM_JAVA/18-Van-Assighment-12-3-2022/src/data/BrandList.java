package data;

import java.util.ArrayList;
import java.util.StringTokenizer;
import util.FileHandler;
import util.Inputter;
import util.Menu;

public class BrandList extends ArrayList<Brand> {

    FileHandler<Brand> fh_brand = new FileHandler<Brand>() {
        @Override//Muốn có 1 thg đọc file thì phải chỉ nó cách biến 1 file thành từng dòng
        public Brand handleLine(String line) {
            StringTokenizer st = new StringTokenizer(line, ",");
            String brandID = st.nextToken().trim();//trim dùng để xóa khoảng trắng
            String brandName = st.nextToken().trim();
            String subStr = st.nextToken().trim();
            st = new StringTokenizer(subStr, ":");
            String soundBrand = st.nextToken().trim();
            double price = Double.parseDouble(st.nextToken().trim());
            //tạo
            Brand newBrand = new Brand(brandID, brandName, soundBrand, price);
            return newBrand;
        }
    };

    public boolean loadFromFile(String filename) {
        return fh_brand.load(filename, this);//dùng this do mình chính là cái List 
    }

    public boolean saveToFile(String filename) {
        return fh_brand.save(this, filename);
        //lưu những gì có trong danh sách vào file
    }

    public int searchID(String bID) {
        //Không nên dùng fore vì nó không trả vị trí
        for (int i = 0; i <= this.size() - 1; i++) {
            if (this.get(i).getBrandID().equals(bID)) {
                return i;
            }
        }
        return -1;
    }

    //
    public Brand getUserChoice() {
        Menu<Brand> brandMenu = new Menu("List of brands to choice for creating car");
        return brandMenu.ref_getChoice(this);//this là brandList
    }

    //
    public void addBrand() {
        System.out.println("Create new brand");
        String brandID;
        while (true) {
            brandID = Inputter.getAString("Input Brand ID: ", "Brand ID is required");
            if (isDup(brandID)) {
                System.out.println("BrandID has been used before");
            } else {
                break;
            }
        }
        String brandName = Inputter.getAString("Input Brand Name: ", "Brand Name is required");
        String soundBrand = Inputter.getAString("Input soundBrand: ", "soundBrand is required");
        double price = Inputter.getADouble("Input price: ", "Price must be positive real number", 0, Double.MAX_VALUE);
        //tạo từ những cái đã xin
        Brand newBrand = new Brand(brandID, brandName, soundBrand, price);
        //thêm vào danh sách brandList (là mình luôn - this)
        this.add(newBrand);
    }

    //Hàm kiểm tra trùng: tìm trả true/false
    public boolean isDup(String brandID) {
        for (Brand brand : this) {
            if (brand.getBrandID().equals(brandID)) {
                return true;
            }
        }
        //
        return false;
    }

    public Brand findBrandByBrandID(String brandID) {
        for (Brand brand : this) {
            if (brand.getBrandID().equals(brandID)) {
                return brand;
            }
        }
        //
        return null;
    }

    //
    public void updateBrand() {
        System.out.println("Update iformation of brand ");
        String brandID = Inputter.getAString("Inpute brandID you wanna update", "BrandID is required");
        //dùng Brand id xin được để tìm brand
        Brand brand = findBrandByBrandID(brandID);//brand | null
        if (brand == null) {
            System.out.println("The brand doesn't exist");
            return;// chửi xong nghỉ
        }
        //nếu tìm được thì xử lí
        // sẽ update
        System.out.println("The information of brand before updating");
        System.out.println(brand);//tự dộng lấy chuỗi đẹp để in
        //xin thông tin để update
        String brandName = Inputter.getAString("Input new Brand Name: ", "Brand Name is required");
        String soundBrand = Inputter.getAString("Input new soundBrand: ", "soundBrand is required");
        double price = Inputter.getADouble("Input new price: ", "Price must be positive real number", 0, Double.MAX_VALUE);
        //xin xong set
        brand.setBrandName(brandName);
        brand.setSoundBrand(soundBrand);
        brand.setPrice(price);
        //thông báo
        System.out.println("The information of brand after updating");
        System.out.println(brand);
    }

    //
    public void searchBrand() {
        System.out.println("Search information of brand ");
        String brandID = Inputter.getAString("Inpute brandID you wanna search", "BrandID is required");
        //dùng Brand id xin được để tìm brand
        Brand brand = findBrandByBrandID(brandID);//brand | null
        if (brand == null) {
            System.out.println("The brand doesn't exist");
            return;// chửi xong nghỉ
        }
        //nếu tìm được thì xử lí
        // sẽ update
        System.out.println("The information of brand");
        System.out.println(brand);//tự dộng lấy chuỗi đẹp để in
    }
    public void listBrands(){
        for (Brand brand : this) {
            System.out.println(brand);//tự động toString()
        }
        //
        if(this.isEmpty()){
            System.out.println("Nothing to print");
        }
    }
}
