package data;

public class Car implements Comparable<Car> {

    private String carID;
    private Brand brand;
    private String color;
    private String frameID;
    private String engineID;
    //contructor

    public Car() {
    }

    public Car(String carID, Brand brand, String color, String frameID, String engineID) {
        this.carID = carID;
        this.brand = brand;
        this.color = color;
        this.frameID = frameID;
        this.engineID = engineID;
    }
    //getter và setter

    public String getCarID() {
        return carID;
    }

    public Brand getBrand() {
        return brand;
    }

    public String getColor() {
        return color;
    }

    public String getFrameID() {
        return frameID;
    }

    public String getEngineID() {
        return engineID;
    }

    public void setCarID(String carID) {
        this.carID = carID;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setFrameID(String frameID) {
        this.frameID = frameID;
    }

    public void setEngineID(String engineID) {
        this.engineID = engineID;
    }
    //

    @Override
    public int compareTo(Car that) {
        int result = this.getBrand().getBrandName().compareTo(that.getBrand().getBrandName());
        if (result != 0) {
            return result;//nếu không bằng thì đổi chỗ đi
        }        //nếu bằng thì sắp xếp theo carID
        return this.getCarID().compareTo(that.getCarID());
    }

    @Override
    public String toString() {//hàm lấy chuỗi đẹp để lưu vào file
        return String.format("%s,%s,%s,%s,%s,", carID, brand.getBrandID(), color, frameID, engineID);
    }

    public String screenString() {//hàm lấy chuỗi đẹp để hiển thị trong app
        //brand, “\n”, car_ID, color, frameID, engineID
        return String.format("%s,\n \t%s,%s,%s,%s,", brand, carID, color, frameID, engineID);
    }
    
}
