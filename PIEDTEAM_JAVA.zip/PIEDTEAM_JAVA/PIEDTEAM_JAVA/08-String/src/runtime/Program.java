
package runtime;

import java.util.StringTokenizer;

public class Program {
    public static void main(String[] args) {
        String lastName = new String("Điệp");
        String tmp = lastName;
        String firstName = "Lê";//pool
        //String trong java không phải là array index như trong C
        //String trong java là obj immutable(bất biến thiên)
        //Không có method nào có thể thay đổi obj này
        
        //Lúc này con trỏ lastName còn đang trỏ tới obj "Điệp"
        lastName = lastName.concat(firstName);//Hướng con trỏ vào obj mới tên "Điệp Lê"
        //do đã tạo ra obj mới tên Điệp Lê
        System.out.println("lastName = " +lastName);//Điệp lê
        System.out.println("tmp = " +tmp);//Điệp
        //Bất kỳ thao tác cố gắng thay đổi chuỗi đều tạo ra obj mới
        
        //pool
        String s0 = new String("ABC");
        String s1 = "ABC";//pool
        String s2 = "ABC";//pool
        String s3 = "abc";//pool
        String s4 = new String("ABC");
        String s5 = new String("ABC");
        
        
        System.out.println(s1 == s2);
        //Những thg tạo bằng pool có chung giá trị sẽ được xài chung
        
        //java sẽ hướng đối tượng ng dùng dùng pool để lưu trữ để giảm dung lượng
        //nhưng sẽ immutable string để tránh hiệu ứng đổ domino
        
        //String là immutable nên tất cả các method trong String đều không có
        //khả năng thay đổi String mà thường sẽ trả ra 1 String chứa kết quả đã
        //thay đổi *khi mà xài method phải để ý xem method có return cái gì
        
        String str1 = "Điệp";
        String str2 = "Đẹp trai";
        str1 = str1.concat(str2).concat("Quá").toUpperCase();
        System.out.println(str1);
        char ch = str1.charAt(2);//Ệ
        int pos = str1.indexOf(str2);//Tìm chuỗi 2 bên trong chuỗi 1    vị trí:4
        boolean b = str1.contains(str2);//str1 có chứa str2 không ? trả ra true hoặc false
        
        //StringTokenizer | split | hash : băm
        //Dùng để lấy thông tin chính xác nhất
        String information = "SE19000|Điệp Đẹp Trai|2005|9.9";
        StringTokenizer st = new StringTokenizer(information, "|");
        System.out.println(st.countTokens());//4
        System.out.println(st.hasMoreTokens());//true
        String id = st.nextToken();
        String name = st.nextToken();
        int yob = Integer.parseInt(st.nextToken());
        double point = Double.parseDouble(st.nextToken());
        System.out.println(st.countTokens());//0
        System.out.println(st.hasMoreTokens());//false
        
    }
}
