package runtime;
/*
trong 1 file java có thể có nhiều class nhưng chỉ có 1 class là public thôi vì class
đó đại diện cho file đó khi import file đó là import class đó (module)

lambda 
*/
public class Program {

    public static void main(String[] args) {
        Math diep = (int a, int b) ->{
            return a + b;
        };
        //Viết tắt:
        //Match diep = (a, b) -> a,b;
    }

}
//inter
interface Math{
    public int sum (int a, int b);//abs method
}