
package runtime;

import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        //Regex: Regular Expression | pattern | Biểu thức chính quy
        //1 chuối mô tả cấu trúc chuẩn
        String regex1 = "^[Ss][Ee]\\d{9}$";
        System.out.println("Se123456789".matches(regex1));
        //1.Ký tự cố định
        System.out.println("name".matches("name"));//true
        System.out.println("nAme".matches("name"));//false
        
        
        //2.ignore case: (?i)
        System.out.println("nAme".matches("(?i)name"));//true
        //không quan tâm chữ thường hay hoa
        
        
        //3.any character(trừ dấu enter): '.'
        System.out.println("".matches("m.y"));
        //vd: may mey myy m9y m_y    true
        //my                      false
        //chấp nhận 1 ký tự bất kỳ xuất hiện giữa m và y
        
        
        //4.lặp lại 1 ký tự phía trước(cho phép đi từ 0 đến n lần)
        System.out.println("".matches("me*y"));
        //my  mey  meey  meeeeeeeey      true
        
        
        //5.lặp lại 1 ký tự phía trước từ 0 đến 1 '?'(có hoặc không)
        
        
        //6. Group () cho khả năng nhóm các ký tự muốn lặp
        
        
        //7. SET: tập hợp[...]chỉ được chọn 1 ký tự xuất hiện trong ngoặc
        System.out.println("".matches("m[abc]y"));
        //may mby mcy      true
        //m9y              false
        System.out.println("".matches("m[^abc]y"));
        //thêm dấu ^ là ngoại trừ nếu nó đứng đầu trong ngoặc vuông
        //may mby mcy   false
        //m9y           true
        
        
        //8.Bộ khớp
        //[a-z]: 1 ký tự chữ thường
        //[A-z]: 1 ký tự chữ hoa
        //[A-Za-z]: 1 ký tự chữ hoa/thường
        //[0-9]: 1 ký tự số
        
        
        //9.Bộ giới hạn lặp
        //{4} lặp lại từ 2-4 lần
        //{2,4} lặp lại 2 đến 4 lần
        //{2,} lặp lại 2 trở lên
        //{1,} '+' lặp lại 1 lần trở lên
        //{0,} '*' lặp lại 0 lần trở lên
        //{0,1}'?' optional
        
        
        //10.OR (a|b)
        
        
        //11.shorthand: viết tắt
        //\w: [a-zA-Z0-9_]  
        //\W: [^a-zA-Z0-9_]
        //\d: [0-9]
        //\D:
        //\s:space
        //\S: 1 ký tự bất kỳ khác space
        
        //$: là kết thúc
        //\: 'escape character' phế võ công thg kế tiếp
        
        
        
        //Try catch
        //Error compilation:Lỗi phát sinh trong quá trình biên dịch
        //Thường diễn ra vơi người mới
        
        //Error run time: Lỗi phát sinh trong quá trình chạy code
        //Lỗi làm đứng chướng trình trong quá trình chạy (Đa số do người dùng)
        
        //Error logic:Lỗi ngu
        
        //scanf(): là hàm lấy giá trị từ hệ thống trong C
        //Trong java không có hàm nhưng có 1 (class)thg chuyên scan mọi thứ
        
        Scanner sc = new Scanner(System.in);
        int age = 0;

        System.out.println("Nhap tuoi di: ");//20\n 
        try{
        age = sc.nextInt();
            if(age < 10 || age > 35){
                throw new Exception();
            }
        }catch(Exception e){
        //Exception: ngoại lệ
            System.out.println("Mày nhập sai rồi");
        }
        //finally{
        //}
        //Kiểu gì cũng xuống finally nên bth sẽ bỏ qua
        
        
        System.out.println("Tuổi nè: " +age);
    }
    
}
