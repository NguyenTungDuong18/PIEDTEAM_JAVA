
package runtime;
//Wrapper: bao bọc
//Wrapper class là lớp bao bọc các kiểu dữ liệu nguyên thủy (primitive) trong Java, cho phép chúng được xử lý như các đối tượng (object).
import javax.sound.midi.Soundbank;

public class Program {
    public static void main(String[] args) {
        int a = 10;//primitive datetype
        //a.    không được do đây là nhỏ nhất
        Integer b = new Integer(10);//boxing
        //Integer là wrapper class của int
        //tạo ra obj chứa core là 10
        //b là obj đc tạo từ wrapper class Integer
        //b(core và các method hỗ trợ xử lý core)
        //kích thước b > a
        System.out.println(a);
        System.out.println(b);//Tại sao không in ra địa chỉ: vì wrapper class có auto - unboxing
        //thay vì phải in ra địa chỉ thì nó tự lần theo địa chỉ tới obj mở ra
        // và lấy core để in ra
        System.out.println(b.toString());//nếu in bth
        
        int c = b;//vì b là wrapper nên có cơ chế auto-unboxing nên nó sẽ ko lưu địa chỉ
        // mà sẽ lưu giá trị ở địa chỉ đó
        Integer d = 2000;//new Integer(2000);//boxing
        //Khi mà wrapper và primitive chơi với nhau thì sẽ có auto-unboxing
        d = 2000;//Wrapper => boxing
        b = 2000;//Wrapper => boxing
        a = 2000;//Primitive gán
        
        //khi so sánh
        //Primitive và wrapper sẽ có auto-unboxing nên dùng == là so sánh về mặt giá trị
        //Wrapper mà so sánh wrapper thì xem như so sánh 2 obj
        //ko có auto-unboxing gì cả => == là so sánh địa chỉ
        // muốn so sánh giá trị      .equals()     .compareTo()
        
        /*
        Xét về lưu trữ thì dùng primitive
        
        Hầu hết các method trong wrapper đều static (thuộc về class)
        mục đích là khuyến khích em xài trực tiếp từ class thày vì phải tạo obj
        nó muốn dùng class như cái rương chứa các method(hàm|công cụ) xử lý số
        */
        //Ví dụ cách dùng
        String str = "10.5";
        double e = Double.parseDouble(str);//ép kiểu
    }
}
