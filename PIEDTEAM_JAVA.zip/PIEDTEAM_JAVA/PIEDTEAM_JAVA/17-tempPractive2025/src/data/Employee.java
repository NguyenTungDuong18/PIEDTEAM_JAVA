package data;

//thỏa thích sáng tạo ở đây
import util.Inputter;

public class Employee {

    private String id;
    private String name;
    private int yob;
    private int salary;
    private String title;
    //contructor

    public Employee() {
    }

    public Employee(String id, String name, int yob, int salary, String title) {
        this.id = id;
        this.name = name;
        this.yob = yob;
        this.salary = salary;
        this.title = title;
    }
    //getter

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getYob() {
        return yob;
    }

    public int getSalary() {
        return salary;
    }

    public String getTitle() {
        return title;
    }

    public void showInfor() {
        String str = String.format("%-10s|%-10s|%-5d|%-5d|%-10s", id, name, yob, salary, title);
        System.out.println(str);
    }

    public void updateSalary(String id) {
        this.id = id;
        this.salary = Inputter.getAnInteger("Nhập mức lương mới:", "Không được bỏ trống", 0, 100000);
    }
}
