package manager;

import java.util.ArrayList;
import data.Employee;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import util.Inputter;
//được phép code trong file này, nhưng không được xóa

public class EmpListManager {

    private ArrayList<Employee> empList = new ArrayList<>();

    public void add() {
        String id;
        while (true) {
            id = Inputter.getAString("Nhập ID :", "Sai định dạng!!", "^EMP\\d{3}$");
            if (search(id) != null) {
                System.out.println("Mã nhân viên đã tồn tại");
            } else {
                break;
            }
        }
        String name = Inputter.getAString("Nhập tên :", "Không được bỏ trống");
        Integer yob = Inputter.getAnInteger("Nhập năm sinh:", "Không được bỏ trống", 1990, 2000);
        Integer salary = Inputter.getAnInteger("Nhập lương: ", "Không được bỏ trống", 0, 10000);
        String title = Inputter.getAString("Nhập chức danh:", "Không được bỏ trống");
        Employee newEmp = new Employee(id, name, yob, salary, title);
        empList.add(newEmp);
    }

    public void searchById() {
        String id = Inputter.getAString("Nhập ID cần tìm: ", "Sai định dạng", "^EMP\\d{3}$");
        Employee emp = search(id);
        if (emp != null) {
            emp.showInfor();
        } else {
            System.out.println("Không tìm thấy");
        }
    }

    public void updateInfor() {
        String id = Inputter.getAString("Nhập ID:", "Sai định dạng", "^EMP\\d{3}$");
        Employee emp = search(id);
        if (emp == null) {
            System.out.println("Không tồn tại nhân viên");
            return;
        }
        emp.updateSalary(id);
    }

    public void removeEmp() {
        String id = Inputter.getAString("Nhập ID:", "Sai định dạng", "^EMP\\d{3}$");
        Employee emp = search(id);
        if (emp == null) {
            System.out.println("Không tồn tại nhân viên");
            return;
        }
        empList.remove(emp);
    }

    public void sortOrderBySalaryAsc() {
        Comparator<Employee> OrderBySalary = new Comparator<Employee>() {
            @Override
            public int compare(Employee emp1, Employee emp2) {
                if (emp1.getSalary() > emp2.getSalary()) {
                    return 1;
                } else {
                    return -1;
                }
            }
        };
        Collections.sort(empList, OrderBySalary);
        for (Employee employee : empList) {
            employee.showInfor();
        }
    }

    public void getListEmpByTitle() {
        Comparator<Employee> OrderBySalary = new Comparator<Employee>() {
            @Override
            public int compare(Employee emp1, Employee emp2) {
                return emp1.getTitle().compareTo(emp2.getTitle());
            }
        };
        Collections.sort(empList, OrderBySalary);
        for (Employee employee : empList) {
            employee.showInfor();
        }
    }

    public Employee search(String id) {
        for (Employee employee : empList) {
            if (employee.getId().equals(id)) {
                return employee;
            }
        }
        return null;
    }
}

//1.Thêm nhân sự vào danh sách
//2.Tìm kiếm thông tin nhân sự bằng id
//3.Cập nhật lương của nhân sự bằng id
//4.xóa thông tin nhân sự bằng id
//5.sắp xếp nhân sự theo lương tăng dần
//6.Hiển thị danh sách nhân sự theo chức danh cần tìm
