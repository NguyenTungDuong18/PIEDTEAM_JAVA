package list;
import data.Cat;
import data.Dog;
import data.Pet;
import java.util.Collections;
import java.util.StringTokenizer;
import list.PetList;
import sun.util.locale.StringTokenIterator;
import util.FileHandler;
public class Cabinet {

    private PetList petList = new PetList();
    private FileHandler<Pet> fileHandler = new FileHandler<Pet>(){
        @Override
        public Pet handleLine(String line) {
            //D001 | Diep | RED | 23.5 | vong bac (line)
            StringTokenizer st = new StringTokenizer(line, "|");//băm theo dấu xổ xuống
            String id = st.nextToken().trim();// trim để xóa đi phần trống bị thừa
            String owner = st.nextToken().trim();
            String color = st.nextToken().trim();
            double weight = Double.parseDouble(st.nextToken().trim());
            String special = st.nextToken().trim();
            if(id.contains("D")){
                return new Dog(id, owner, color, weight, special);
            }else{
                return new Cat(id, owner, color, weight, color);
            }
        }
        
    };
    
    public void loadFromFile(){
        String url = "C:\\Users\\Admin\\OneDrive\\Desktop\\PIEDTEAM_JAVA-20250912T131831Z-1-001\\PIEDTEAM_JAVA\\pet.txt";
        fileHandler.load(url, petList);
    }
    
    public void saveToFile(){
        String url = "C:\\Users\\Admin\\OneDrive\\Desktop\\PIEDTEAM_JAVA-20250912T131831Z-1-001\\PIEDTEAM_JAVA\\pet.txt";
        fileHandler.save(petList, url);
    }
    public void task1() {
        petList.addNewDog();
        
    }

    public void task2() {
        petList.addNewCat();
    }

    public void task3() {
        petList.show();
    }

    public void task4() {
        petList.search();
    }

    public void task5() {
        petList.update();
    }

    public void task6() {
        petList.remove();
    }

    public void task7() {
        Collections.sort(petList);
    }

}
