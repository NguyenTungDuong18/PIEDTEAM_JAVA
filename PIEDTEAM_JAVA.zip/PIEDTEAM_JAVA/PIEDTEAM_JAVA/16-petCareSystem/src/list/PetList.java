package list;

import data.Cat;
import data.Dog;
import data.Pet;
import java.util.ArrayList;
import util.Inputter;

public class PetList extends ArrayList<Pet> {

    public void addNewDog() {
        Dog newDog = new Dog();
        newDog.inputInfor();
        this.add(newDog);
        System.out.println("Thêm thú cưng thành công !!!");
    }

    public void addNewCat() {
        Cat newCat = new Cat();
        newCat.inputInfor();
        this.add(newCat);
        System.out.println("Thêm thú cưng thành công !!!");
    }

    public void show() {
        boolean isFind = false;
        for (Pet pet : this) {
            pet.showInFor();
            isFind = true;
        }
        
        if(!isFind) System.out.println("Không có thú cưng nào trong danh sách");
    }
    
    //Tìm Pet
    public Pet findPetById(String id){
        for (Pet pet : this) {
            if(pet.getId().equals(id)) return pet;
        }
        //
        return null;
    }
    
    public void search(){
        String id = Inputter.getAString("Nhập mã thú cưng cần tìm: ", "Mã thú cưng không được bỏ trống");
        Pet pet = findPetById(id);
        if(pet == null){
            System.out.println("Không tìm được");
            return;//Ngừng chức năng
        }
        //xử lý
        System.out.println("Thông tin thú cưng tìm được nè: ");
        pet.showInFor();
        
    }
    public void remove(){
        String id = Inputter.getAString("Nhập mã thú cưng cần xóa: ", "Mã thú cưng không được bỏ trống");
        Pet pet = findPetById(id);
        if(pet == null){
            System.out.println("Không tìm được");
            return;//Ngừng chức năng
        }
        //xử lý
        System.out.println("Thông tin thú cưng trước khi xóa: ");
        pet.showInFor();
        this.remove(pet);//xóa con pet vừa tìm được trong danh sách
        System.out.println("Xóa thú cưng thành công");
    }
    //
    public void update(){
        String id = Inputter.getAString("Nhập mã thú cưng cần cập nhật: ", "Mã thú cưng không được bỏ trống");
        Pet pet = findPetById(id);
        if(pet == null){
            System.out.println("Không tìm được");
            return;//Ngừng chức năng
        }
        //xử lý
        System.out.println("Thông tin thú cưng trước khi cập nhật nè: ");
        pet.showInFor();
        //tiến hành cập nhật
        pet.update();
        System.out.println("Thông tin thú cưng sau update");
        pet.showInFor();
    }
}
