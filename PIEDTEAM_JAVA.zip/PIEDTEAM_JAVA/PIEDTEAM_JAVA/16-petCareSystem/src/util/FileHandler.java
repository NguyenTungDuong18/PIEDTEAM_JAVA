package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import static java.util.Collections.list;
import javafx.scene.shape.Line;

public abstract class FileHandler <T>{
    public boolean load(String url, ArrayList <T> List){//nhận vào đường link và mảng xịn tên là list
        List.clear();//dọn trước khi lưu
        File f = new File(url);
        try {
            FileReader fr = new FileReader(f);
            BufferedReader reader = new BufferedReader(fr);
            String line = reader.readLine();
            while (line != null) {
                //xử lý line thành T
                T t = handleLine(line);
                List.add(t);
                line = reader.readLine();  
            }
            return true;
        } catch (IOException | NumberFormatException e) {
            System.out.println("File lỗi rồi");
            return false;
        }
    }
    public abstract T handleLine(String line);
    
    public boolean save(ArrayList <T> list, String url){
        File f = new File(url);
        try{
            FileOutputStream fos = new FileOutputStream(f);//Giúp cho file nằm lên cái bàn để viết(Đặt file lên luồn đi ra để đè tín hiệu lên)
            OutputStreamWriter writter = new OutputStreamWriter(fos);//Người viết lên cái bàn
            for (T item : list) {
                writter.write(item.toString());
                writter.write("\n");
            }
            writter.flush();//xóa những phần thừa khi viết file
            return true;
        }catch(Exception e){
            System.out.println("File lỗi rồi");
            return false;
        }
    }
}
