
package data;

import util.Inputter;

public class Cat extends Pet{
    private String ribbon;
    //contructor

    public Cat() {
    }

    public Cat(String id, String owner, String color, double weight, String ribbon) {
        super(id, owner, color, weight);
        this.ribbon = ribbon;
    }
    //getter

    public String getRibbon() {
        return ribbon;
    }
    //InputInFor
    public void inputInfor(){
        this.id = Inputter.getAString("Nhập mã con mèo của bạn: ", "Mã con mèo của bạn không đúng định dạng !!!", "^C\\d{3}$");
        //xin owner color weight
        super.inputInFor();
        this.ribbon = Inputter.getAString("Nhập thông tin ruy băng:", "Ruy băng không được bỏ trống !!");
    }

    @Override
    public void showInFor() {
        String str = String.format("%4s|%20S|%20S|%6.2f|%s", id,owner,color,weight,ribbon);
        System.out.println(str);
    }

    @Override
    public String toString() {
        return String.format("%4s|%20S|%20S|%6.2f|%s", id,owner,color,weight,ribbon); 
    }
    
    public void update() {
        super.update();
        this.ribbon = Inputter.getAString("Nhập thông tin ruy băng mới:", "Ruy băng không được bỏ trống !!");
    }
}
