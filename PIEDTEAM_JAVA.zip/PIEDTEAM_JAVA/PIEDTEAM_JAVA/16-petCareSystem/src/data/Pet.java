package data;

import util.Inputter;

public abstract class Pet implements Comparable<Pet> {

    protected String id;
    protected String owner;
    protected String color;
    protected double weight;
    //

    public Pet() {
    }

    //này để đọc file
    public Pet(String id, String owner, String color, double weight) {
        this.id = id;
        this.owner = owner;
        this.color = color;
        this.weight = weight;
    }
    //getter

    public String getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public String getColor() {
        return color;
    }

    public double getWeight() {
        return weight;
    }

    //show
    public abstract void showInFor();

    //InputInFor
    public void inputInFor() {
        //xin owner color weight
        this.owner = Inputter.getAString("Nhập chủ sở hữu của thú cưng:", "Thông tin chủ không được bỏ trống");
        this.color = Inputter.getAString("Nhập màu sắc của thú cưng:", "Màu sắc của thú cưng không được bỏ trống");
        this.weight = Inputter.getADouble("Nhập cân nặng cho thú cưng:", "Cân nặng phải từ 1-100 cân", 1, 100);

    }

    //
    public void update() {
        this.owner = Inputter.getAString("Nhập chủ sở hữu mới của thú cưng:", "Thông tin chủ không được bỏ trống");
        this.color = Inputter.getAString("Nhập màu sắc mới của thú cưng:", "Màu sắc của thú cưng không được bỏ trống");
        this.weight = Inputter.getADouble("Nhập cân nặng mới cho thú cưng:", "Cân nặng phải từ 1-100 cân", 1, 100);
    }

    @Override
    public int compareTo(Pet that) {
        if (this.getWeight() > that.getWeight()) {
            return 1;
        } else {
            return -1;
        }
    }
}
