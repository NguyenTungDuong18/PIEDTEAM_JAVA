package data;

import util.Inputter;

public class Dog extends Pet {

    private String necklace;
    //contructor

    public Dog() {
    }

    public Dog(String id, String owner, String color, double weight, String necklace) {
        super(id, owner, color, weight);
        this.necklace = necklace;
    }
    //getter

    public String getNecklace() {
        return necklace;
    }

    //InputInFor
    public void inputInfor() {
        this.id = Inputter.getAString("Nhập mã chú cún của bạn: ", "Mã chú cún của bạn không đúng định dạng !!!", "^D\\d{3}$");
        //xin owner color weight
        super.inputInFor();
        this.necklace = Inputter.getAString("Nhập thông tin vòng cổ:", "Vòng cổ không được bỏ trống !!");
    }

    @Override
    public void showInFor() {
        String str = String.format("%4s|%20S|%20S|%6.2f|%s", id, owner, color, weight, necklace);
        System.out.println(str);
    }

    @Override
    public String toString() {
        return String.format("%4s|%20S|%20S|%6.2f|%s", id, owner, color, weight, necklace); //To change body of generated methods, choose Tools | Templates.
    }

    public void update() {
        super.update();
        this.necklace = Inputter.getAString("Nhập thông tin vòng cổ mới:", "Vòng cổ không được bỏ trống !!");
    }
}
