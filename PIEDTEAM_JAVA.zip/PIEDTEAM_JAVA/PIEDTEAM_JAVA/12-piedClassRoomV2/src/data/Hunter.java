
package data;

import java.util.Random;
//Hunter chăm chỉ học, quên ăn luôn => ham học
public class Hunter implements StudyEnthusiasts{
    //props 
    private String name;
    private int yob;
    private double weight;
    private String gear;
    //Bác thợ săn học mà cứ nhìn phò mã nên 50%
    public static final double RECEPTIVE = 50;
    //contrucstor

    public Hunter(String name, int yob, double weight, String gear) {
        this.name = name;
        this.yob = yob;
        this.weight = weight;
        this.gear = gear;
    }

   
    public double study() {
        Random rd = new Random();
        return rd.nextDouble()* RECEPTIVE;//rd.nextDouble luôn trả dao động trong 0.0 đến 1.0
    }

    
    public void showInfor() {
        String str = String.format("HUNTER|%-15s|%4d|%-6.2f|%5.2f|%s", name, yob, weight, study(), gear);
        System.out.println(str);
    }

    @Override
    public double studyHard() {
        return study() * 1.5;
    }

    @Override
    public void showHard() {
        String str = String.format("HUNTER|%-15s|%4d|%-6.2f|%5.2f|%s", name, yob, weight, studyHard(), gear);
        System.out.println(str);
    }
}
