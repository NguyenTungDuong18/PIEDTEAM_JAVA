
package data;
/*
Là hội những người đam mê học tập nếu ,bác thợ săn tập trung học mà ko nhìn con ngựa
học quan trọng hơn ăn uống => học ko màng ăn
nếu mà con ngựa dù biết có bác thợ săn vẫn đi học thì chứng tỏ quan trọng việc học
hơn mạng sống của mình => ham học
nếu ngựa và bác thợ săn làm được việc đó thì sẽ vào được hội ham học học quên ăn, quên mạng

hội này chỉ cần biết rằng mày có ham học hay không nếu mày có thì vào ngoài ra không quan tâm gì hết

StudyEnthusiasts là 1 interface
Interface là 1 class nhưng chỉ chứa method không quan tâm prop

*/
//tư duy ngược: t là ng ban phát điểm chung ai muốn về 1 nhà thì tham gia vào hội của tao
public interface StudyEnthusiasts {
    //ai cũng vào hội được hết, vào hội này thì phải học chăm chỉ
    //trong interface không có prop
    //bởi vì khi có prop đồng nghĩa việc khi vào hội phải cung cấp cái prop đó => phân biệt
    //chỉ chấp nhận prop là hằng số
    public String colorSkin = "Black";
    //public static final String colorSkin = "Black"; đồ xài chung
    //Không lưu được thuộc tính => cái khuôn không có ngăn
    //Không cần đến contructor
    //không có getter và setter
    //tóm lại trong interface thì ko có prop nếu có thì nó là đồ xài chung không chỉnh sửa
    //Ai tham gia vào hội sẽ có cái cớ đẻ vào 1 nhóm
    public double studyHard();
    //có thể dùng Static
    //quy ước: 1 là ko có
    //         2 là đồ xài chung
    //         3 là abs method
    public void showHard();
    
    //ai vào hội này thì sẽ nhận được 2 lỗ thủng này và nhiệm vụ là vá để vào hội
    //trên thực tế interface chỉ chứa 1 method duy nhất để làm lambda thôi
}
