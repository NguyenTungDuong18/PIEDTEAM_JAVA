
package data;
//Herbivore là động vật ăn cỏ
//nên chỉ chứa điểm chung của 2 con này mà thôi cha của khỉ và ngựa
//nếu herbivore vào hội studyenthusists thì nghĩa là con vật ăn cỏ nào cũng ham học
// => vậy thì không thể chửi ngu "như bò được"
public abstract class Herbivore {
    //props
    protected String name;
    protected int yob;
    protected double weigth;
    //contructor

    public Herbivore(String name, int yob, double weigth) {
        this.name = name;
        this.yob = yob;
        this.weigth = weigth;
    }
    //getter và setter
    //method
    public abstract double study();//muốn khi học phải trả ra kết quả là điểm nên để double
    //mỗi con vật có cách học khác nhau không áp đặt
    public abstract void showInfor();//mỗi con vật sẽ in khác nhau
}
