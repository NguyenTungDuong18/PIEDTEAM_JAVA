package runtime;

import data.Herbivore;
import data.Horse;
import data.Hunter;
import data.Monkey;
import data.StudyEnthusiasts;
import java.util.ArrayList;

/*
Ở bài trước mình đã giúp khỉ và ngựa về cùng 1 lớp đc nhờ vào việc "lấy lý do là chúng"
nó đều ăn cỏ(mặt sinh học)'Herbivore'
Sau đó có 1 đối tượng khác tuy có nhiều điểm tương đồng nhưng lại không có điểm chung
về mặt sinh học nên không có thể viện cớ được

        Interface là 1 class (Hội) nhưng không dùng dể đúc mà dùng để lưu trữ(cái cớ) các cá thể có cùng tiêu chí ví dụ Ham học
        tư duy đúng : tao là ng ban phát điểm chung và cho 2 thg bất kỳ điểm chung là ham học khi nó tham gia vào hội(không tuyển thành viên,
        ai cũng lấy và khi vào hội mới ban phát điểm chung) nên không có thuộc tính tại vì tụi nó cần hội chứ hội không cần tụi nó và ko quan tâm
        tụi nó là ai
        Dùng interface làm cái cớ nó dễ chấp nhập hơn dùng tập hợp lớn 1 cách lố bịch và dễ bảo trì hơn do cái cớ tập hợp đơn giản hơn
        Interface là 1 abs class, được sử dụng như danh sách những việc cần làm

Vậy thì mình sẽ gom nhóm tụi này theo mặt đam mê chứ ko phải sinh học tìm 1 hội nhóm và đưa nó vào

 */
public class Program {

    public static void main(String[] args) {
        Monkey m1 = new Monkey("Rafiki", 1998, 210);
        Horse h1 = new Horse("Rarity", 2015, 9, "none");
        Herbivore h2 = new Horse("Roach", 2019, 170, "Gray");
        Hunter hun1 = new Hunter("thợ săn vượn", 1999, 65, "Nỏ");

        ArrayList<StudyEnthusiasts> stuList = new ArrayList<>();
        stuList.add(h1);
        stuList.add((Horse) h2);
        stuList.add(hun1);

        //Hôm nay bỗng nhiên có 1 con vật bước vô lớp đó là con lười (Sloth) tưởng là bạn
        //mới hóa ra là bạn chùm kín mít hôm bữa, hôm nay trời không lạnh nên bạn 
        //mặc đồ hở hang nên nhận ra là con lười
        //1.Tạo con lười bằng herbivore => không vào danh sách được
        //2. Tại class Sloth và cho implement studyEnthusisat
        // vậy thì con lười nào cx ham học
        //3.COn lười của mình dặc biết ham học => mình nên dùng cái khuôn ham học
        //để đúc nó luôn tránh ảnh hưởng tới giống loài
        StudyEnthusiasts xxx = new StudyEnthusiasts() {
            @Override
            public double studyHard() {
                return 120;
            }

            @Override
            public void showHard() {
                String str = String.format("XXXXX|%-15s|%4d|%-6.2f|%5.2f", "Flash", 2018, 120, studyHard());
                System.out.println(str);
            }
        };
        stuList.add(xxx);
    }
}
/*
                         ABS class                                        Interface
Thuộc tính:                                        Thuộc tính:
Quan tâm đến cái chung của đối tượng những mỗi đối| Thuộc tính bắt buộc là hằng số, và phải là của chung
tượng sẽ xài riêng                                | của các dối tượng
                                                  |Method:
Method:                                           | luôn luôn là abs method
Có method bth và abstract method                  | một interface chuẩn thì chỉ có duy nhất 1 hàm mà thôi ( để dáp ứng lambda của JDK9 )
                                                  | nếu hàm có body thì nó phải là static hoặc non - static đi kèm default
                                                  | để tránh việc bể code do không tương thích interface
                                                        
*/

/*
anonymous là kỹ thuật tạo obj từ cái khuôn bị thủng
abs class:
không nhất thiết phải có abs method

anonymous: 
- Lười / ngại
- Không biết đặt tên là gì
- Ảnh hưởng đến giống loài của nó

interface và abs class :
prop abs tạo bth còn inter phải có static final để biến thành của chung 
1-interface như là 1 hội chung đam mê (Tư duy giải thích)
2-Tao là ng ban phát điểm chung (Tư duy tạo ra) tư duy đúng

Method:abs class có thể có method bth và abs method còn interface như là 1 cái to do list
khi gia nhập thì phải làm nhiệm vụ thì sẽ có điểm chung 

Về mặt kế thừa: đối với abs class kế thừa, khôi phục , vá và phát triển còn interface là vá

sử dụng: Đối với abs class từ khóa là extends để kế thừa để vá hoặc phát triển, khôi phục
còn interface từ khóa là implements làm rõ và vá (implemetn là con của extend)

abs class là đơn kế thừa interface CÓ THỂ HIỂU LÀ ĐA KẾ THỪA


*/