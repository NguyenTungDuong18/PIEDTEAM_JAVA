 
package manager;
//Cabinet là cái thùng chứa các hàm sẽ xuất hiện ở main
public class Cabinet {
    private MajorListManager majorListmanager = new MajorListManager();
    private StudentListManager studentListManager = new StudentListManager();
    //
    public void initData(){
        majorListmanager.initData();
        studentListManager.initData();
    }
    //
    public void task1(){
        majorListmanager.addNewMajor();
    }
    //
    public void task2(){
        String mid = majorListmanager.getMidByMenu();
        studentListManager.addNewStudentListWithMid(mid);
    }
    //
    public void task3(){
        studentListManager.showStudentListByMid();
    }
    //
    public void task4(){
        studentListManager.getHighestGpaOfStudentGroupByMajor();
    }
    //
    public void task5(){
        studentListManager.showStudentListOrderByMajorAscAndGpaDesc();
    }
}
