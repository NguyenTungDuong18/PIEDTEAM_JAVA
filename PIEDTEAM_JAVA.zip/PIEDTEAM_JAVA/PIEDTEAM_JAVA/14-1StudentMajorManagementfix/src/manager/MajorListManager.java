
package manager;

import data.Major;
import java.util.ArrayList;
import util.Inputter;
import util.Menu;

/*
1.function: MajorListManager người quản lý danh sách
    - có danh sách
    - các method hỗ trợ xử lý danh sách
2.oop: Tôi là list trong tao có
    các method hỗ trợ xử lý tao
*/
public class MajorListManager {
    private ArrayList<Major> majorList = new ArrayList<>();
    //thêm mới 1 major
    public void initData(){
        this.majorList.add(new Major("SE", "Kỹ thuật phần mềm", "R001"));
        this.majorList.add(new Major("AI", "Trí tuệ nhân tạo", "R002"));
        this.majorList.add(new Major("ES", "Ngôn ngữ anh", "R003"));
    }
    //thêm mới 1 major
    public void addNewMajor(){
        //tạo mới major
        //xin giá trị
        //mId: String và phải cấm 
        String mId;
        while(true){
        mId = Inputter.getAString("Nhập mã chuyên ngành: ", "Mã chuyên ngành không đúng định dạng", "^[A-Z]{2}$");
            if(findMajorByMid(mId) != null){
                System.out.println("Mã chuyên ngành bị trùng");
            }else{
                break;
            }
        }
        //name
        String name = Inputter.getAString("Nhập tên chuyên ngành: ",
                                "Tên chuyên ngành không được bỏ trống");
        //room
        String room = Inputter.getAString("Nhập mã phòng ban(Rxxx): ", 
                                    "Mã phòng bạn không đúng định dạng",
                                    "^R\\d{3}$");
        //rót vào phễu đúc luôn
        Major newMajor = new Major(mId, name, room);
        //thêm Major mới vào majorList
        this.majorList.add(newMajor);
        System.out.println("Thêm chuyên ngành thành công");
    }
    //hàm nhận vào mid tìm major tương ứng
    public Major findMajorByMid(String mId){//đưa mã cần tìm
        Major result = null;//ban đầu xác định là null
        for (Major major : majorList) {//trong quá trình đi tìm, nếu ko tìm đc thì trả là null, 
                                    //còn tìm ra thì trả ra thằng đó
            if(major.getmId().equals(mId))  result = major;
        }
        return null;
    }
    //hàm hiển thị majorList dạng menu và cho người dùng chọn
    public String getMidByMenu(){
        //tạo menu bằng majorList
        Menu majorMenu = new Menu("Danh sách chuyên ngành có thể chọn");
                
        for (Major major : majorList) {
            majorMenu.addNewOpt(major.toString());// toString : j  cung cấp thông tin dưới dạng chuỗi
        }
        //hiển thị menu cho người dùng chọn
        majorMenu.print();
        int choice = majorMenu.getChoice();
        //return  mã chuyên ngành đã chọn ra bên ngoài
        return majorList.get(choice - 1).getmId();
    }
            
}
