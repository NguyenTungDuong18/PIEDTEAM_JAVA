/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import data.Student;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import util.Inputter;

public class StudentListManager {

    private ArrayList<Student> studentlist = new ArrayList<>();

    //
    public void initData() {
        this.studentlist.add(new Student("SE001", "Lê", "An"   , 2005, 5 , "SE"));
        this.studentlist.add(new Student("SE002", "Lê", "Bình" , 2005, 3 , "AI"));
        this.studentlist.add(new Student("SE003", "Lê", "Cường", 2005, 6 , "SE"));
        this.studentlist.add(new Student("SE004", "Lê", "Dũng" , 2005, 5 , "SE"));
        this.studentlist.add(new Student("SE005", "Lê", "Điệp" , 2005, 10, "SE"));
    } 

    public void addNewStudentListWithMid(String mid) {
        //có mid sẵn rồi
        //mình chỉ in
        //sid: có regex,cấm trùng
        String sid;
        while (true) {
            sid = mid + Inputter.getAString("Nhập mã sinh viên: ",
                    "Mã sinh viên không đúng định dạng", "^\\d{3}$");//SE001
            if (findStudentBySid(sid)) {
                System.out.println("Mã sinh viên bị trùng rồi");
            } else {
                break;
            }
        }
        //fname
        String firstName = Inputter.getAString("Nhập tên của sinh viên",
                "Tên sinh viên không bỏ trống");
        //lname
        String lastName = Inputter.getAString("Nhập tên của sinh viên",
                "Họ sinh viên không bỏ trống");
        //yob
        int yob = Inputter.getAnInteger("Nhập tuổi: ",
                "Tuổi không bỏ trống");
        //gpa
        double gpa = Inputter.getADouble("Nhập điểm: ",
                "Điểm phải từ 1 đến 10", 1, 10);
        //tạo newStudent từ những cái đã xin đc
        Student newStudent = new Student(sid, firstName, lastName, yob, gpa, mid);

        //nhét newStudent vào danh sách
        studentlist.add(newStudent);
        //thông báo hoàn thành
        System.out.println("Thêm sinh viên thành công");
    }

    //
    public boolean findStudentBySid(String sid) {
        for (Student student : studentlist) {
            if (student.getsId().equals(sid)) {
                return true;
            }
        }
        return false;
    }

    public void showStudentListByMid() {
        String mid = Inputter.getAString("Nhập mã chuyên ngành cần tìm sinh viên",
                "Mã chuyển ngành cần tìm không bỏ trống");
        boolean isFind = false;
        //
        for (Student student : studentlist) {
            if (student.getmId().equals(mid)) {
                student.showInfor();
                isFind = true;
            }
        }
        if (!isFind) {
            System.out.println("Không có sinh viên nào !!!!");
        }
    }

    public void showStudentListOrderByMajorAscAndGpaDesc() {
        Comparator<Student> orderBymajotAsc = new Comparator<Student>() {
            @Override
            public int compare(Student stu1, Student stu2) {
                return stu1.getmId().compareTo(stu2.getmId());
            }
        };
        //
        Collections.sort(studentlist, orderBymajotAsc);
        //
        Comparator<Student> sameMidOrderByGpaDesc = new Comparator<Student>() {
            @Override
            public int compare(Student stu1, Student stu2) {
                if (stu1.getmId().equals(stu2.getmId())) {
                    if (stu1.getGpa() < stu2.getGpa()) {
                        return 1;
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
            }
        };
        Collections.sort(studentlist, sameMidOrderByGpaDesc);
    }

}
