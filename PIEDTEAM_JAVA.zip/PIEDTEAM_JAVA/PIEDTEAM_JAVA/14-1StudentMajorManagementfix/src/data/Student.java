
package data;
public class Student {
    private String sId;
    private String firstname;
    private String lastname;
    private int yob;
    private double gpa;
    private String mId;

    public Student(String sId, String firstname, String lastname, int yob, double gpa, String mId) {
        this.sId = sId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.yob = yob;
        this.gpa = gpa;
        this.mId = mId;
    }

    public String getsId() {
        return sId;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public int getYob() {
        return yob;
    }

    public double getGpa() {
        return gpa;
    }

    public String getmId() {
        return mId;
    }
    
    //showInfor
    public void showInfor(){
        //sId: SE001
        String str = String.format("%5s|%20s|%-20s|%4d|%5.2f|%2s",
                sId, firstname, lastname, yob, gpa, mId);
        System.out.println(str);
    }
            
            
}
/*
Student
  Sid, firstName, lastName, yob, Gpa,MId
  phểu rỗng, phễu có full đối số, phễu chỉ có MId
  getter
  showInfor
*/
