/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;
//Menu là cái khuôn chuyên tạo menu
//cần tạo menu thì gọi khuôn ra đúc

import java.util.ArrayList;

public class Menu {

    private String title;
    private ArrayList<String> optionList;

    //contructor
    public Menu(String title) {
        this.title = title;
        optionList = new ArrayList<>();
    }

    public void addNewOpt(String newOtp) {
        this.optionList.add(newOtp);
    }

    public void print() {
        System.out.println(this.title);
        int count = 1;
        for (String opt : optionList) {
            System.out.println(count + ". " + opt);
            count++;
        }
    }

    public int getChoice() {
        //mời nhập lựa chọn
        return Inputter.getAnInteger("Nhập lựa chọn của bạn: ", "Lựa chọn phải từ 1 đến " + this.optionList.size(), 1, this.optionList.size());

    }
}
