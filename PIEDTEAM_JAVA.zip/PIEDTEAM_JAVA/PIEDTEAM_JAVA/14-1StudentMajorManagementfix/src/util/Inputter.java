// muốn nập thì ogji thằng này
package util;
//Inputter là cái khuôn 
//nhưng ko dùng để đúc obj

import java.util.Scanner;

//mà dùng để chứa các hàm công cụ (method) để giúp việc nhập dễ hơn
public class Inputter {
    private static Scanner sc = new Scanner(System.in);
    
    //hàm ép nhấp số nguyên
    public static int getAnInteger(String inputMsg, String errMsg){
        while(true){
            try{
                System.out.println(inputMsg);
                int value = Integer.parseInt(sc.nextLine());
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    //Hàm ép nhập số nguyên có giới hạn
    public static int getAnInteger(String inputMsg, String errMsg,
            int lowerBound, int upperBound){
        while(true){
            try{
                System.out.println(inputMsg);
                int value = Integer.parseInt(sc.nextLine());
                if(value < lowerBound || value > upperBound){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    //hàm ép nhập chuỗi, không bỏ trống
    public static String getAString(String inputMsg, String errMsg){
        while(true){
            try{
                System.out.println(inputMsg);
                String value = sc.nextLine();
                if(value.isEmpty()){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    //hàm ép nhập chuỗi, theo định dạng
    public static String getAString(String inputMsg, String errMsg,
                                    String regex){
        while(true){
            try{
                System.out.println(inputMsg);
                String value = sc.nextLine();
                if(value.isEmpty()  ||  !value.matches(regex)){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    
    //hàm ép nhấp số thực
    public static double getADouble(String inputMsg, String errMsg){
        while(true){
            try{
                System.out.println(inputMsg);
                double value = Double.parseDouble(sc.nextLine());
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    //Hàm ép nhập số thực có giới hạn
    public static double getADouble(String inputMsg, String errMsg,
            double lowerBound, double upperBound){
        while(true){
            try{
                System.out.println(inputMsg);
                double value = Double.parseDouble(sc.nextLine());
                if(value < lowerBound || value > upperBound){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
}
