
package runtime;

import manager.Cabinet;
import util.Menu;

public class Program {

    public static void main(String[] args) {
        Cabinet cabinet = new Cabinet();
        cabinet.initData();
        //tạo menu
        Menu mainMenu = new Menu("Menu quản lý sinh viên");
        mainMenu.addNewOpt("Thêm chuyên ngành");
        mainMenu.addNewOpt("Thêm sinh viên vào chuyên ngành");
        mainMenu.addNewOpt("Hiển thị dách sách sinh viên của chuyên ngành nào đó");
        mainMenu.addNewOpt("Hiển sinh viên viên cao điểm nhất của mỗi chuyên ngành");
        mainMenu.addNewOpt("sắp xếp sinh viên theo chuyên ngành asc, và điểm desc");
        mainMenu.addNewOpt("quit");
        //in menu
        while(true){
            mainMenu.print();
            //xin choice
            int choice = mainMenu.getChoice();
            //xử lý choice
            switch(choice){
                case 1:{
                    cabinet.task1();
                    break;
                }
                case 2:{
                    cabinet.task2();
                    break;
                }
                case 3:{
                    cabinet.task3();
                    break;
                }
                case 4:{
                    break;
                }
                case 5:{
                    cabinet.task5();
                    break;
                }
                case 6:{
                    System.out.println("Bye");
                    return;//nghỉ luôn
                }
            }
        }
   }
}

//cabinet là nơi tụ tất cả các hàm
/*  
Quản lý sinh viên và cách chuyên ngành sinh viên theo học
Student
  Sid, firstName, lastName, yob, Gpa,MId
  phểu rỗng, phễu có full đối số, phễu chỉ có MId
  getter
  showInfor
Major
  MId, name, room
  phễu rỗng, phễu full
  getter
  showInfor

Menu
 1.Thêm chuyên ngành
 2.Thêm sinh viên vào chuyên ngành
    2.1 hiển thị menu con các chuyên ngành có thể thêm, để chọn
    2.2 tạo sinh viên dựa vào chuyên ngành đã chọn
 3.Hiển thị dach sách sinh viên của chuyên ngành nào đó
 4.Hiển sinh viên viên cao điểm nhất của mỗi chuyên ngành
 5.sắp xếp sinh viên theo chuyên ngành asc, và điểm desc
 6.quit
*/
