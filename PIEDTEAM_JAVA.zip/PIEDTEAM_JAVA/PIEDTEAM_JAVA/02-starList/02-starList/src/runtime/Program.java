
package runtime;

import data.Star;


public class Program {
    
    public static void main(String[] args) {
        //tạo ra 1 ngôi sao là MTP
        Star mtp = new Star("Sơn Tùng", 1994, "Nam", "Cơn mưa ngang qua");
        mtp.showInfor();
        
        Star chiPuc = new Star("Thùy Chi", 1993, "Nữ", "Chiếc Ố");
        chiPuc.showInfor();
    }
         
}

/*
Lý thuyết 
I-Modifier
    1.Access Modifier
       - Default: Là những thằng trong cùng 1
                 package có thể truy câp được.

       - Public: là tất cả mọi người đều có quyền truy cập.
                 Nhưng mình k thể nhìn thấy lại mng.    

       - Private: là không ai truy cập được. 

       - Protected: được chia sẻ với các thế hệ sau. chỉ những ng ko kế thừa hoặc khác package mới không  truy cập được

       !!!Trong JAVA có quy tắc bất hiếu: Cha cho con tất cả cha có. Nhưng con sẽ không cho cha bất cứ gì hết.
                                        
       - Trong 1 Access Modifier chỉ có 1 trong 4 thằng này được xuất hiện mà thôi.

    2.Non Access Modifier
       - Override: vượt mặt(độ lại)
       Ý nghĩa của kế thừa là thừa hưởng những gì người đi trước đã làm tốt rồi,
       hoặc cải tiến những gì người khác làm chưa tốt hoặc chưa có 
       
       - final: class | prop | method 
            final method: method này k được độ lại nữa 
            final class: class này bị vô sinh, k nhận class khác làm con được
            final prop: không được thay đổi giá trị sau khi gán nếu có static thì là hằng số 

       - static: tĩnh
            static: method | prop
            khi có static nghĩa là method | prop đó thuộc sở hữu của class
            không phải của instance(object) được tạo ra từ class đó.
            các obj tạo từ class có static được sờ vào được thay đổi nhưng không được thay đổi khi có final

       - abstraction: trừu tượng
            class bth mà có abstract method thì là abstract class
            abstract class thì k nhất thiết phải có abstract method 
*/



























