
package data;


public class Star {
    //property | field | attribute: thuộc tính 
    private String name;
    private int yob;
    private String gender;
    private String hotSong;
    //method
    //constructor: cái phễu dùng để nhận giá trị từ bên ngoài và rót 
    // giá trị vào các properties tương ứng, từ đó đúc ra bức tượng 
    // 1.constructor phải có tên giống với Class chứa nó 
    // 2.constructor là hàm kh được xét về đầu ra 
    // 3.phải PUBLIC
    // this: là object (bản thân nó) đang gọi method đó 

    public Star() {
    }

    public Star(String name, int yob, String gender, String hotSong) {
        this.name = name;
        this.yob = yob;
        this.gender = gender;
        this.hotSong = hotSong;
    }
    //getter và setter

    public String getName() {
        return name;
    }

    public int getYob() {
        return yob;
    }

    public String getGender() {
        return gender;
    }

    public String getHotSong() {
        return hotSong;
    }
    
    
    public void showInfor(){
        System.out.println("Tôi tên là: " + name +
                           ", sinh năm : " + yob +
                           ", giới tính: " + gender +
                           ", hotSong là: " + hotSong);
    }
    
    
}
