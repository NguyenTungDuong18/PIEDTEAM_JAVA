
package data;

import java.util.ArrayList;
import java.util.Scanner;

public class Author {
    private String name;
    private String nickName;
    private int yob;
    //constructor

    public Author(String name, String nickName, int yob) {
        this.name = name;
        this.nickName = nickName;
        this.yob = yob;
    }

    public Author() {
    }

    public Author(String nickName) {//Lưu ý
        this.nickName = nickName;
    }
    //Getter

    public String getName() {
        return name;
    }

    public String getNickName() {
        return nickName;
    }

    public int getYob() {
        return yob;
    }
    //inputInFor: nhập thông tin cho tác giả
    public void inputInfor(){//nhập name và yob
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập tên tác giả: ");
        this.name = sc.nextLine();
        System.out.println("Nhập năm sinh: ");
        this.yob = Integer.parseInt(sc.nextLine());
        
        
    }
    public void inputInfor(ArrayList<Author> authorList){
        //nhập nickname và kiểm tra chúng
        Scanner sc = new Scanner(System.in);
        
        while(true){
            System.out.println("Nhập bút danh của tác giả: ");
            String inputNickName = sc.nextLine();
            boolean isDup = false;
            
           
            //duyệt kiểm tra trùng
            for (Author author : authorList) {
                if(author.getNickName().equals(inputNickName)){
                    isDup = true;
                }
            }
            
            
            if(isDup){
                    System.out.println("Bút danh bị trùng rồi làm lại đi: ");
            }else{
                this.nickName = inputNickName;//lưu lại
                this.inputInfor();//nhập name, yob
                break;//thoát lập
            }
        }
    }
    //show
    public void showInfor(){
        System.out.println("%-20s|%-20s|%4d\n" + name + nickName + yob);
    }
}
