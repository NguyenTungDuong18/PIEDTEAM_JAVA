
package data;

import java.util.Scanner;

public class Book {
    
    //props
    private String bookName;
    private String createAt;
    private String nickName;//tên của tác giả viết sách
    //constructor

    public Book() {
    }

    public Book(String bookName, String createAt, String nickName) {
        this.bookName = bookName;
        this.createAt = createAt;
        this.nickName = nickName;
    }
    //getter
    public String getBookName() {
        return bookName;
    }

    public String getCreateAt() {
        return createAt;
    }

    public String getNickName() {
        return nickName;
    }
    //inputInfor()
    public void inputInFor(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập tên sách: ");
        this.bookName = sc.nextLine();
        
        System.out.println("Nhập ngày phát hành sách: ");
        this.createAt = sc.nextLine();
        
        System.out.println("Nhập nick name tác giả: ");
        this.nickName = sc.nextLine();
    }
    //show
    public void showInfor(){
        System.out.printf("|%-20s|%-20s|%-20s\n", bookName, createAt, nickName);
    }
    
}
