
package runtime;

import data.Author;
import data.Book;
import java.util.ArrayList;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //Tạo mảng
        ArrayList<Author> authorList = new ArrayList<>();
        ArrayList<Book> bookList = new ArrayList<>();
        //nạp data mẫu
        authorList.add(new Author("Ngô kiến Huy", "Bắp", 1984));
        authorList.add(new Author("Trịnh Trần Phương Tuấn", "J97", 1997));
        authorList.add(new Author("Lê Mười Điệp","UncleTen", 1999));
        
        bookList.add(new Book("Dạy người giàu xài tiền", "2025", "Bắp"));
        bookList.add(new Book("Nuôi tóc không nuôi con", "2025", "J97"));
        bookList.add(new Book("Lấy 10 điểm cực Chill", "2025", "UncleTen"));
        //
        int choice;
        do{
            printMenu();
            System.out.println("Mời nhập lựa chọn:");
            choice = Integer.parseInt(sc.nextLine());
            switch(choice){
                case 1:{
                    //tạo mới sách
                    Book newBook = new Book();
                    newBook.inputInFor();//bookname, createAt, nickname
                    //kiểm tra xem nickname của cuốn sách có nằm trong dánh sách
                    //tác gia không ?
                    //nếu chưa có thì tạo mới tác giả đó
                    //tìm xem có hay không
                    boolean isFind = false;
                    for (Author author : authorList) {
                        if(author.getNickName().equals(newBook.getNickName())){
                            isFind = true;
                        }
                    }
                    //nếu không tìm thấy thì tạo mới tác giả
                    if(!isFind){
                        Author newAuthor = new Author(newBook.getNickName());//ràng buộc người dùng vào cái phễu có nickname
                        newAuthor.inputInfor();//chỉ nhập 2 props không bao gồm nickname
                        authorList.add(newAuthor);//lưu
                    }
                    //và lưu sách ở ngoài
                    bookList.add(newBook);
                    break;
                }
                case 2:{
                    for (Book book : bookList) {
                        book.showInfor();
                        
                    }
                    break;
                }
                case 3:{
                    //Tạo mới tác giả
                    Author newAuthor = new Author();
                    newAuthor.inputInfor(authorList);
                    authorList.add(newAuthor);
                    break;
                }
                case 4:{
                    //nhập nickName tìm các sách của tác giả đó
                    System.out.println("Nhập bút danh của tác giả cần tìm sách: ");
                    String keyNickName = sc.nextLine();
                    boolean isFind = false;
                    for (Book book : bookList) {
                        if(book.getNickName().equals(keyNickName)){
                            book.showInfor();
                            isFind = true;
                        }
                        
                    }
                    if(!isFind){
                        System.out.println("Không có trong danh sách cần tìm");
                    }
                    break;
                }
                case 5:{
                    System.out.println("Hẹn gặp lại");
                    break;
                }
                default:{
                    System.out.println("Phải nhập từ 1 đến 5");
                    break;
                }
            }
        }while(choice !=5 );
    }
    public static void printMenu(){
    System.out.println("1.Nhập thông tin sách in ra màn hình");
    System.out.println("2.Hiển thị thông tin sách ra màn hình");
    System.out.println("3.Nhập thông tin tác giả");
    System.out.println("4.Tìm kiếm sách theo bút danh");
    System.out.println("5.Thoát");
    }
}
/*
sinh viên có học bổng là sinh viên có điểm trên >= 8 nhen


---- bài mới ----
quản lý thư viện

tạo chương trình quản lý thư viện
gồm 2 class sau
Author
    name nickname old birthday;
    tạo phểu hàm không đối số
    tạo phểu có đối số 
    tạo phểu có đối số là nickname
    tạo getter không tạo setter
    tạo hàm nhập thông tin tác giả
    nhưng nếu tác giả đã tồn tại trong danh sách thì k cho
    ép nhập lại
    tạo hàm showInfor
Book
    bookName createAt nickName
    tạo có đối số và k có đồi số
    tạo getter anh setter
    tạo hàm input//nếu mà sách này có tác giả mà 
    có tên trong danh sách tác giả thì bỏ qua
    nếu tác giả của cuốn sách mà chưa có tồn tại trong ds
    thì thêm mới
program:
    menu
    1.Nhập thông tin sách in ra màn hình
    2.Hiển thị thông tin sách ra màn hình
    3.Nhập thông tin tác giả
    4.Tìm kiếm sách theo bút danh
    5.Thoát
*/


