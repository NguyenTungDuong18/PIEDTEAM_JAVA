package manager;

import data.Major;
import java.util.ArrayList;
import util.Inputter;
import util.Menu;

/*
class chứa hàm xử lý MajorList

oop:

funtion MajorListManager: cái khuôn tạo ra người quản lí danh sách 1 ng quản lý
danh sách thì có
  danh sách
*/
public class MajorListManager {
    private ArrayList<Major> majorList = new ArrayList<>();
    //thêm mới 1 major
    public void initData(){
        this.majorList.add(new Major("SE", "Kỹ thuật phần mềm", "R001"));
        this.majorList.add(new Major("AI", "Trí tuệ nhân tạo", "R002"));
        this.majorList.add(new Major("ES", "Ngôn ngữ anh", "R003"));
    }
    public void addNewMajor(){
        //nhập đủ
        //mId: cấm trùng
        String mId;
        while(true){
             mId = Inputter.getAString("Nhập mã chuyên nghành (XX)", "Mã vừa nhập không đúng định dạng!!", "^[A-Z]{2}$");
            boolean isDup;
            if(this.findMajorByMid(mId) != null){
                System.out.println("Mã chuyên nghành bị trùng");
            }else{
                break;//thoát vòng lặp
            }
        }
        //name
        String name = Inputter.getAString("Nhập tên của chuyên nghành:", "Tên chuyên nghành không bỏ trống");
        //room
        String room = Inputter.getAString("Nhập mã phòng ban:", "Mã phòng ban phải có định dạng Rxxx", "^R\\d{3}$");
        //rót phễu đúc luôn
        Major newMajor = new Major(mId, name, room);
        this.majorList.add(newMajor);
        System.out.println("Thêm chuyên nghành mới thành công !!!!");
    }
    //Hàm nhận vào mid tìm major tương ứng
    public Major findMajorByMid(String mId){
        for (Major major : majorList) {
            if(major.getmId().equals(mId)){
                return major;
            }  
        }
        return null;
    }
    //Hàm hiển thị MajorList dạng menu và cho người dùng chọn
    public String getMidByMenu(){
        //tạo menu bằng majorList
        Menu majorMenu = new Menu("Danh sách chuyên nghành có thể chọn:");
        for (Major major : majorList) {
            majorMenu.addNewOption(major.toString());
        }
        //hiển thị menu cho người dùng chọn
        majorMenu.print();
        int choice = majorMenu.getChoice();
        //return mã chuyên nghành đã chọn ra bên ngoài
        return majorList.get(choice - 1).getmId();
    }
}
