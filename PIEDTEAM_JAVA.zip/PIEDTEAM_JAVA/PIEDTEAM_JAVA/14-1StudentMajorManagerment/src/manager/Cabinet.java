
package manager;
//Cabinet là cái thùng chứa các hàm sẽ xuất hiện ở main
public class Cabinet {
    private MajorListManager majorListManager = new MajorListManager();
    private StudentListManager studentListManager = new StudentListManager();
    //
    public void initData(){
        majorListManager.initData();
        studentListManager.initData();
        
    }
    public void task1(){
        majorListManager.addNewMajor();
    }
    //
    public void task2(){
        String mid = majorListManager.getMidByMenu();
        studentListManager.addNewStudentWithMid(mid);
    }
    //
    public void task3(){
        studentListManager.showStudentListByMid();
    }
    //
    public void task4(){
        studentListManager.getHigestGpaOfStudentGroupByMajor();
    }
    //
    public void task5(){
        studentListManager.showStudentListOrderByMajorAscAndGpaDesc();
    }
}
