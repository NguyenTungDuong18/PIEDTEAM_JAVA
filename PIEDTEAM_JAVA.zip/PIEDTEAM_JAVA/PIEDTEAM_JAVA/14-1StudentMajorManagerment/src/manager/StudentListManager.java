package manager;

import data.Student;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import util.Inputter;

public class StudentListManager {

    private ArrayList<Student> studentList = new ArrayList<>();

    //
    
    public void initData(){
        this.studentList.add(new Student("SE001", "Lê", "An", 2005, 5, "SE"));
        this.studentList.add(new Student("SE002", "Lê", "Bình", 2005, 3, "AI"));
        this.studentList.add(new Student("SE003", "Lê", "Cường",2005, 6, "ES"));
        this.studentList.add(new Student("SE004", "Lê", "Dũng",2005,  5, "SE"));
        this.studentList.add(new Student("SE005", "Lê", "Điệp",2005,  10, "SE"));
        
    }
    public void addNewStudentWithMid(String Mid) {
        //có mid sẵn rồi
        //mình chỉ xin
        //sid: có regex, unique: cấm trùng
        String sid;
        while (true) {
            sid = Inputter.getAString("Nhập mã sinh viên: ", "Mã sinh viên không đúng định dạng", "^\\d{3}$");
            if (findStudentBySid(sid)) {
                System.out.println("Mã sinh viên bị trùng rồi");
            } else {
                break;
            }
        }
    }
    //fname
    String firstName = Inputter.getAString("Nhập tên của sinh viên", "Nhập tên của sinh viên không bỏ trống");
    //lname
    String lastName = Inputter.getAString("Nhập họ của sinh viên", "Nhập họ của sinh viên không bỏ trống");
    //yob
    int yob = Inputter.getAnInterger("Nhập tuổi: ", "Tuổi không bỏ trống");
    //gpa
    double gpa = Inputter.getADouble("Nhập điểm: ", "Điểm phải từ 1 đến 10");

    //tạo newStudent
    //nhét newStudent vào danh sách
    //thống báo hoàn thành
    public boolean findStudentBySid(String sid) {
        for (Student student : studentList) {
            if (student.getSid().equals(sid)) {
                return true;
            }
        }
        return false;
    }

    public void showStudentListByMid() {
        String mid = Inputter.getAString("Nhập mã chuyên nghành cần tìm sinh viên", "Mã chuyển nghành cần tìm không bỏ trống");
        //
        boolean isFind = false;
        //
        for (Student student : studentList) {
            if (student.getmId().equals(mid)) {
                student.showInfor();
                isFind = true;
            }
        }
        //nếu không(!!!) tìm thấy ai
        if (!isFind) {
            System.out.println("Không có xinh viên cần tìm");
        }
    }

    public void showStudentListOrderByMajorAscAndGpaDesc() {
        Comparator<Student> orderByMajorAsc = new Comparator<Student>() {
            @Override
            public int compare(Student stu1, Student stu2) {
                return stu1.getmId().compareTo(stu2.getmId());
            }
        };
        //
        Collections.sort(studentList, orderByMajorAsc);
        //
        Comparator<Student> sameMidOrderByGpaDesc = new Comparator<Student>() {
            @Override
            public int compare(Student stu1, Student stu2) {
                if (stu1.getmId().equals(stu2.getmId())) {
                    if (stu1.getGpa() < stu2.getGpa()) {
                        return 1;
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
            }
        };
        //
        Collections.sort(studentList, sameMidOrderByGpaDesc);
        //show
        for (Student student : studentList) {
            student.showInfor();
        }
    }
    
}
