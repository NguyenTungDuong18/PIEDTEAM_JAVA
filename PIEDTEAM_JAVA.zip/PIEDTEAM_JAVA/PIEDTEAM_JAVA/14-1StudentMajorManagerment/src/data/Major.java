package data;

public class Major {
    private String mId;
    private String name;
    private String room;//R001

    public Major(String mId, String name, String room) {
        this.mId = mId;
        this.name = name;
        this.room = room;
    }

    public String getmId() {
        return mId;
    }

    public String getName() {
        return name;
    }

    public String getRoom() {
        return room;
    }
    public void showInfor(){
        String str = String.format("%2s|%-20s|%4s", mId, name, room);
        System.out.println(str);
    }

    @Override
    public String toString() {
        return String.format("%2s|%-20s|4s", mId, name,room);
    }
    
    
}
