package data;

public class Student {
    private String Sid;
    private String firstName;
    private String lastName;
    private int yob;
    private double gpa;
    private String mId;

    public Student(String Sid, String firstName, String lastName, int yob, double gpa, String mId) {
        this.Sid = Sid;
        this.firstName = firstName;
        this.lastName = lastName;
        this.yob = yob;
        this.gpa = gpa;
        this.mId = mId;
    }

    public Student() {
    }

    public Student(String mId) {
        this.mId = mId;
    }

    public String getSid() {
        return Sid;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getYob() {
        return yob;
    }

    public double getGpa() {
        return gpa;
    }

    public String getmId() {
        return mId;
    }
    
    public void showInfor(){
        
        String str = String.format("%-5s|%-20s|%-20s|%4d|%5.2f|%2s", Sid,firstName, lastName, yob, gpa, mId);
        System.out.println(str);
    }
}
