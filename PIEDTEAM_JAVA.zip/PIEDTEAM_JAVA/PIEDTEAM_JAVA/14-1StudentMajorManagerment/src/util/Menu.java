
package util;

import java.util.ArrayList;

/*
Chuyên dùng để tạo menu
*/
public class Menu {
    private String title;
    private ArrayList<String> optList;
    //contructor
    public Menu(String title){
        this.title = title;
        this.optList = new ArrayList<>();//danh sách rỗng
    }
    public void addNewOption (String newOpt){
        this.optList.add(newOpt);
    }
    
    public void print(){
        int count = 1;
        for (String opt : optList) {
            System.out.println(count +"." + opt);
            count ++;
        }
    }
    //hàm lấy lựa chọn từ người dùng
    public int getChoice(){
        return Inputter.getAnInterger("Nhập lựa chọn của bạn:", "Lựa chọn phải từ 1 dến" + this.optList.size(), 1, this.optList.size());
    }
}
