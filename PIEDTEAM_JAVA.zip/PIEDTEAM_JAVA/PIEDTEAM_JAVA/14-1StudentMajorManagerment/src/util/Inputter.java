package util;

import java.util.Scanner;

/*
Inputter là cái hòm chứa các method hỗ trợ cho việc nhập liệu
tức là khi nào muốn nhập 1 giá trị gì thì xài
*/
public class Inputter {
    public static Scanner sc = new Scanner(System.in);
    //Hàm ép nhập số nguyên
    public static int getAnInterger(String inputMsg, String errMsg){
        while(true){
            try{
                System.out.println(inputMsg);
                int value = Integer.parseInt(sc.nextLine());
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    
     public static int getAnInterger(String inputMsg, String errMsg, int lowerBound, int upperBound){
        while(true){
            try{
                System.out.println(inputMsg);
                int value = Integer.parseInt(sc.nextLine());
                if(lowerBound > value || upperBound < value){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
     
     //Hàm ép nhập chuỗi không được bỏ trống
     public static String getAString(String inputMsg, String errMsg){
        while(true){
            try{
                System.out.println(inputMsg);
                String value = sc.nextLine();
                if(value.isEmpty()){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
     
     //Hàm ép nhapjc chuỗi theo định dạng
     public static String getAString(String inputMsg, String errMsg, String regex){
        while(true){
            try{
                System.out.println(inputMsg);
                String value = sc.nextLine();
                if(value.isEmpty() || !value.matches(regex)){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    //Hàm ép nhập số thực
    public static double getADouble(String inputMsg, String errMsg){
        while(true){
            try{
                System.out.println(inputMsg);
                double value = Double.parseDouble(sc.nextLine());
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
    
     public static double getADouble(String inputMsg, String errMsg, double lowerBound, double upperBound){
        while(true){
            try{
                System.out.println(inputMsg);
                double value = Double.parseDouble(sc.nextLine());
                if(lowerBound > value || upperBound < value){
                    throw new Exception();
                }
                return value;
            }catch(Exception e){
                System.out.println(errMsg);
            }
        }
    }
}
