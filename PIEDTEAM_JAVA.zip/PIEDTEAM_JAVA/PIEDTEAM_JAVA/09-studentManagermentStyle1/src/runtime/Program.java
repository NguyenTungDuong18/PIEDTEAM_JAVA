
package runtime;

import data.Student;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;


public class Program {

    public static void main(String[] args) {
        //ArrayList mảng xịn => co giãn => rất nhiều method hỗ trợ
        ArrayList<Student> studentList = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        int choice;
        do{
        //in menu
            printMenu();
            System.out.println("Nhập lựa chọn");
            choice = Integer.parseInt(sc.nextLine());
            //xử lí lựa chọn
            switch(choice){
                case 1:{
                    System.out.println("Thêm sinh viên");
                    Student newStudent = new Student();
                    newStudent.inputInfor();
                    studentList.add(newStudent);
                    System.out.println("Thêm sinh viên thành công");
                    break;
                }
                case 2:{
                    System.out.println("Danh sách sinh viên");
                    for(Student student : studentList){
                        student.ShowInfor();
                    }
                    if(studentList.isEmpty()){
                        System.out.println("Không có ai trong danh sách");
                    }
                    break;
                }
                case 3:{
                    //tìm max
                    double maxPoint = studentList.get(0).getGpa();
                    double minPoint = studentList.get(0).getGpa();
                    for(Student student : studentList){
                        if(student.getGpa() > maxPoint) maxPoint = student.getGpa();
                        if(student.getGpa() < minPoint) minPoint = student.getGpa();
                    }
                    
                    //in
                    System.out.println("Danh sách sinh viên có điểm lớn nhất");
                    for(Student student : studentList){
                        if(student.getGpa() == maxPoint) student.ShowInfor();
                    }
                    System.out.println("Danh sách sinh viên có điểm bé nhất");
                    for(Student student : studentList){
                        if(student.getGpa() == minPoint) student.ShowInfor();
                    }
                    break;
                }
                case 4:{
                    //tìm kiếm sinh viên dụa theo mã sinh viên
                    //xin người dùng id cần tìm 
                    System.out.println("Nhập id của sinh viên cần tìm: ");
                    String keyId = sc.nextLine();
                    boolean isFind = false;
                    //duyệt danh sách để tìm
                    //duyệt danh sách theo thg khả lập (iterator)
                    //Map và set không đi dc iterator(chưa học tới)
                    for (Student stu : studentList) {
                        if(stu.getId().equals(keyId)){
                            stu.ShowInfor();//tìm đc thì mình trả ra
                            isFind = true;
                        }
                    }
                    //không tìm được thì thông báo
                    if(!isFind){
                        System.out.println("Không có sinh viên cần tìm");
                    }
                    break;
                }
                case 5:{
                    //Sắp xếp sinh viên theo tên và hiển thị
                    if(studentList.isEmpty()){
                        System.out.println("không có sinh viên trong danh sách");
                        break;//Kết thúc case 5
                    }
                    //sắp xếp
                    //tạo anh trọng tài
                    Comparator<Student> trongTai = new Comparator<Student>() {
                        @Override
                        public int compare(Student stu1, Student stu2) {
                            return stu1.getName().compareTo(stu2.getName());
                        }  
                    };
                    //StudentList đang dùng là ArrayList là 1 collection
                    //thì StudentList đc xài bộ tool Collections(Lưu ý để ý chữ s trong chữ collection)
                    Collections.sort(studentList, trongTai);
                    //hiển thị
                    for (Student student : studentList) {
                        student.ShowInfor();
                    }
                    break;
                }
                case 6:{
                    //6.In ra sinh viên có học bổng và hiển thị theo desc
                    //Sắp xếp mảnh hiện tại
                    //Tạo trọng tài
                    Comparator<Student> orderByGpaDesc = new Comparator<Student>() {
                        @Override
                        public int compare(Student stu1, Student stu2) {
                            if(stu1.getGpa() > stu2.getGpa()){
                                return 1;
                            }else{
                                return -1;
                            }
                        }
                    };
                    Collections.sort(studentList, orderByGpaDesc);
                    //duyệt trọng tài có thì show
                    for (Student student : studentList) {
                        if(student.hasScholarship()){
                            student.ShowInfor();
                        }
                    }
                    break;
                }
                case 7:{
                    System.out.println("Hẹn gặp lại !!!");
                    break;
                }
                default:{
                    System.out.println("chọn từ 1 - 7");
                    break;
                }
            }
        }while(choice != 7);
    }
    public static void printMenu(){
        System.out.println("1.Thêm mới 1 sinh viên");
        System.out.println("2.Hiển thị thông tin sinh viên");
        System.out.println("3.Hiển thị max min theo điểm trung bình");
        System.out.println("4.Tìm kiếm theo mã sinh viên");
        System.out.println("5.Sắp xếp sinh viên theo tên asc và hiển thị");
        System.out.println("6.In ra sinh viên có học bổng và hiển thị theo desc");
        System.out.println("7.Thoát");
    }
}
/*
Viết phần mềm quản lý sinh viên gồm các mô tả sau
tạo class Person gồm name, gender, yob
    tạo constructor có đối số
        và constructor không đối số
    làm bộ getter
    làm method showInfor: giúp show thông tin của person
    làm method inputInfor: có nhiệm vụ xin thông tin của người dùng muốn tạo
        person và lưu

tạo class Student kế thừa Person
    sẽ có id, gpa, email
    tạo constructor có đối số và constructor không đối số
    tạo getter
    làm method showInfor
    làm method inputInfor

Menu sẽ gồm các chức năng sau
1.Thêm mới 1 sinh viên
2.Hiển thị thông tin sinh viên
3.Hiển thị max min theo điểm trung bình
4.Tìm kiếm theo mã sinh viên
5.Sắp xếp sinh viên theo tên asc và hiển thị
6.In ra sinh viên có học bổng và hiển thị theo desc
7.Thoát
*/

/*OverLoad và Overdrive đều thể hiện tính đa hình trong java
overdrive: chỉ xuất hiện trong mối quan hệ cha con mà thôi
khi thằng con muốn độ lại method của cha(cùng tên - cùng parameter:tham số)
overload: 2 hàm cùng tên khác parameter => khác cách xài


equals có mục đích tìm chính xác còn compare đc dùng để sắp xếp


Sort
có 3 kiểu sắp xếp 
Kỹ thuật (trong c)
comparator: anh trọng tài
tuyển 1 người về đẻ sắp xếp
comparable: tính đố kỵ
tự động tiêm nhiễm để tụi nó tự ganh đua tạo ra hiện tượng tụi nó tự swap

comparator có tính toàn vẹn và ưu việt hơn hoàn toàn do không cần tiêm nhiễm vào
tụi nó nên không gây biến dạng và có thể thuê nhiều trọng tài để sắp xếp theo nhiều khía 
cạnh còn tính đố kỵ chỉ có thể so sánh trên 1 mặt nhất định
*/