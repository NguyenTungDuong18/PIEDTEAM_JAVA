
package data;

import java.util.Scanner;

public class Student extends Person{
    private String id;
    private double gpa;
    private String email;
    //constructor

    public Student(String name, String gender, int yob, String id, double gpa, String email) {
        super(name, gender, yob);
        this.id = id;
        this.gpa = gpa;
        this.email = email;
    }

    public Student() {
    }

    public boolean hasScholarship(){
        return this.gpa >=8;
    }
    
    public String getId() {
        return id;
    }

    public double getGpa() {
        return gpa;
    }

    public String getEmail() {
        return email;
    }
    //setter

    public boolean setId(String id) {
        boolean isValid = id.matches("^SA\\d{3}$");
            if(!isValid){
                System.out.println("ID không đúng định dạng !!!");
            }else{
                this.id = id;
            }
            return isValid;
    }

    public boolean setGpa(double gpa) {
        boolean isValid = gpa >= 0 && gpa <= 10;
        if(!isValid){
            System.out.println("Điểm phải từ 0 đến 10 !!!");
        }else{
            this.gpa = gpa;
        }
        return isValid;
    }

    public boolean setEmail(String email) {
        boolean isValid = email.length() > 0 && email.contains("@") && email.contains(".");
        if(!isValid){
            System.out.println("Email không hợp lệ ");
        }else{
            this.email = email;
        }
        return isValid;
    }
    
    @Override
    public void ShowInfor(){
        super.ShowInfor();
        System.out.printf("|%s|%f|%s", id, gpa, email);
    }
    
    //InputInfor
    public void inputInfor(){
        super.inputInfor();//nhờ cha nhập dùm name, gender và yob
        //nhập id 
        Scanner sc = new Scanner(System.in);
        String id;
        System.out.println("Nhập Id(SAXXX)");
        
        /*while(true){
            id = sc.nextLine();
            boolean isValid = setId(id);
            if(isValid){
                break;
            }
          }
        */
        
        while(!setId(sc.nextLine()));
        //nhập gpa
        System.out.println("Nhập điểm: ");
        while(!setGpa(Double.parseDouble(sc.nextLine())));
        //nhập email
        System.out.println("Nhập email: ");
        while(!setEmail(sc.nextLine()));
        }
        
    }

