
package data;

import java.util.Scanner;

public class Person {
    //prop
    private String name;
    private String gender;
    private int yob;
    //constructor

    public Person(String name, String gender, int yob) {
        this.name = name;
        this.gender = gender;
        this.yob = yob;
    }

    public Person() {
    }
    //overload
    //getter

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getYob() {
        return yob;
    }
    //showInfor
    public void ShowInfor(){
        System.out.printf("%s|%s|%d", name, gender, yob);//*cố tình không \n
    }
    public void inputInfor(){
        //nhập thông tin
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập tên: ");
        this.name = sc.nextLine();//nhập chuỗi
        System.out.println("Nhập giới tính: ");
        this.gender = sc.nextLine();
        System.out.println("Nhập năm sinh: ");
        this.yob = Integer.parseInt(sc.nextLine());
    }
}
