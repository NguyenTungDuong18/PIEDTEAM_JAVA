
package runtime;


public class Program {
    //public static: modifier (Buổi sau tìm hiểu)
    public static void main(String[] args){
        /*
        Datatype trong java có 2 nhóm chính
        I-primitive datatype: Kiểu dữ liệu nguyên thủy
        =>kiểu dữ liệu nhỏ không thể tách nhỏ đc nữa (atomic: cấp độ nguyên tử)
        Đặt tên: cammelCase: cú pháp con lạc đà
          8 loại dữ liệu nguyên thủy
            1-byte      (1 byte)       số nguyên rất nhỏ
            2-short     (2 byte)       số nguyên hơi nhỏ
            3-int       (4 byte)       số nguyên nhỏ
            4-long      (8 byte)       số nguyên lớn
            5-float     (4 byte)       số thực nhỏ
            6-double    (8 byte)       số thực lớn
            7-char      (2 byte)   ký tự có dấu | hỗ trợ unicode
            8-boolean   (1 bit | quá nhỏ để chỉ định) true|false
        */
        byte numByte = - 128;//-128 -> 127
        int numInt = 1234;
        //numInt = numByte;
        //numByte = numInt; ăn đòn
        float numFloat = 123.4f;
        //java quy ước rằng nếu thấy số thực thì nó là double
        //nếu là số nguyên thì luôn là int
        double numDouble = 123.5;
        long numLong = 10_000_000_000L;
        int num1 = 0xFA; //hệ hexa
        //0x là prefix(tiền tố) của hexa
        int num2 = 076; //octal
        //0 là prefix của octal
        
        // default value của số là 0, chuỗi - ký tự "", boolen là false
        
        /*
        II- references datatype: kiểu dữ liệu tham chiếu
        Object datatype
        kiểu dữ liệu do người dùng tự tạo dựa trên các primitive datatype
        Student(sId: string, yob:int, gpa: float)
        Student là con trỏ
        */
        /*
        Operator: toán tử
        trong java có hơn 10 loại toán tử
        Arithmetic: toán tử toán hạng
        + - * / % += -= *= /= %= ++ --
        assignment: =
        comparison: phép so sánh
        logic: && và || & | !
        */
        System.out.println("num nè" + num1);//line news
        //String
        //Comma: phẩy
        //Unary: toán tử 1 ngôi
        //Relational: toán tử quan hệ
        
        //shift bit: toán tử dịch bit >> <<
        
        /*//đẩy xuống thì rớt|đẩy về thì bù 0
        //x >> n => x/(2^n)
        //x << n => x*(2^n)
        
        //bitwise: toán tử bit (&, |, ^ , ~)
        //&: giống phép nhân, 1 * 1 = 1, còn lại là 0
        //|: có 1 thì phép toán sẽ là 1
        //^: 2 số khác nhau ra 1,giống nhau ra 0
        //~: not, đổi ngược
        */
    }
}

































































