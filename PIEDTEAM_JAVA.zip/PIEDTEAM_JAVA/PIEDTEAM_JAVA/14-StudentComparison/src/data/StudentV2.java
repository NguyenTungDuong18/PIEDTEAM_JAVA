
package data;

public class StudentV2 implements Comparable<StudentV2>{
    private String id;
    private String fname;
    private String lname;
    private double score;
    //contructor

    public StudentV2(String id, String fname, String lname, double score) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.score = score;
    }

    public String getId() {
        return id;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public double getScore() {
        return score;
    }
   //show
    public void show(){
        String str = String.format("%-20s|%-20s|%-20s|%5.2f", id, fname,lname, score);
        System.out.println(str);
    }

    @Override
    public int compareTo(StudentV2 that) {
        return this.getId().compareTo(that.getId());
    }
}
