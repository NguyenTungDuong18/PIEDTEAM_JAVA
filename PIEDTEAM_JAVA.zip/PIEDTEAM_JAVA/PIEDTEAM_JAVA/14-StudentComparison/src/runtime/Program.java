package runtime;

import data.Student;
import data.StudentV2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/*
Sort:
-Thuật toán
-Comparator: anh trọng tài
-Comparable: tính đố kỵ
*/
public class Program {

    public static void main(String[] args) {
       sortV1();//demo comparator
       sortV2();//demo comparable
    }
    public static void sortV1(){//những hàm trực tiếp chơi với main phải là static để không phân nhiều phiên bản
        //tạo danh sách cần sắp xếp
        ArrayList<Student> stuList = new ArrayList<>();
        stuList.add(new Student("SE1", "Lê", "An", 9));
        stuList.add(new Student("SE2", "Nguyễn", "Bình", 8.2));
        stuList.add(new Student("SE5", "Võ", "Cường", 7));
        stuList.add(new Student("SE2", "Quốc", "Dũng", 9.9));
        stuList.add(new Student("SE4", "Hoài", "Em", 5));
        //tạo anh trọng tài
        
        Comparator <Student> ordById = new Comparator<Student>() {
            @Override
            public int compare(Student stu1, Student stu2) {
                return stu1.getId().compareTo(stu2.getId());
            }
        };
        Collections.sort(stuList, ordById);
        /*
        Comparator là 1 interface có hành động là compare nếu mà muốn tạo ra 1 anh trọng tài
        phục vụ cho việc sort thì mình implement method compare
        cung cấp tiêu chí đánh giá thắng thua cho anh trọng tài trước khi ảnh sắp xếp
        */
    }
    public static void sortV2(){
        ArrayList<StudentV2> stuList = new ArrayList<>();
        stuList.add(new StudentV2("SE1", "Lê", "An", 9));
        stuList.add(new StudentV2("SE2", "Nguyễn", "Bình", 8.2));
        stuList.add(new StudentV2("SE5", "Võ", "Cường", 7));
        stuList.add(new StudentV2("SE2", "Quốc", "Dũng", 9.9));
        stuList.add(new StudentV2("SE4", "Hoài", "Em", 5));
    }
}

/*
Những thg thuộc collection thì sẽ được dùng tool của collections

*/
