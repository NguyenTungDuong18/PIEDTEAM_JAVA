
package data;
//class Rectangle: cái khuôn để đúc ra các hình chữ nhật



public class Rectangle {
    //Prop
    private double width;
    protected double height;
    protected String colour;
    //method
    // constructor: phễu
    public Rectangle(double width, double height, String colour) {
        this.width = width;
        this.height = height;
        this.colour = colour;
    }
    //getter
     public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public String getColour() {
        return colour;
    }
    
    public double getperimetor(){
        return (width + height) * 2;
    }
    
    public double getArea(){
        return width * height;
    }
    //paints
    public void paint(){
        String str = String.format("Rectangle|%5.2f|%5.2f|%-10s|%5.2f|%5.2f", width, height, colour, getperimetor(), getArea());
        System.out.println(str);
    }

   
    
}
