
package data;
//class Disk: cái khuôn dùng để đúc hình tròn
public class Disk {
    //prop
    private double radius;
    private String colour;
    public static final double PI = 3.14;
    //constructor

    public Disk(double radius, String colour) {
        this.radius = radius;
        this.colour = colour;
    }
    //getter

    public double getRadius() {
        return radius;
    }

    public String getColour() {
        return colour;
    }
    public double getPerimetor(){
        return PI*radius*2;
    }
    public double getArea(){
        return PI*radius*radius;
    }
      public void paint(){
        String str = String.format("Disk  |%10.2f|%-10s|%5.2f|%5.2f", radius, colour, getPerimetor(), getArea());
        System.out.println(str);
    }
}
