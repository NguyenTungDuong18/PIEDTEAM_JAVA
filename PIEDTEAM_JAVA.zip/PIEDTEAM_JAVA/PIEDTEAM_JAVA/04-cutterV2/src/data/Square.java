
package data;
//class Square : là cái khuôn dùng để đúc ra các hình vuông
//nếu như không nhận Rectangle làm cha, thì Square vẫn tạo object bth
//chỉ là object của Rectangle và Square sẽ không về cùng 1 tập hợp được
//Square is a Rectangle
// con          cha
// Mục đích kế thừa là gì?
//- Thừa hưởng những gì người trước đã làm tốt rồi
//- Phát triển những gì người trước làm chưa tốt hoặc chưa có
public class Square extends Rectangle {

    
    //Liệt kê những prop mà của riêng con
    //edge là width và height nên không được xem là đặc biệt
    //constructor: cái phễu
    public Square(double edge, String colour) {
        super(edge, edge, colour);
    }

    //super: bề trên => new cha => new Rectangle
    @Override
     public void paint(){
        String str = String.format("Square   |%10.2f|%-10s|%5.2f|%5.2f", height, colour, getperimetor(), getArea());
        System.out.println(str);
    }
}
