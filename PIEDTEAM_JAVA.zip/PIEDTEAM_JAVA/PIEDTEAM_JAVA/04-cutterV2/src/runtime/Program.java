
package runtime;

import data.Rectangle;
import data.Square;

public class Program {

    public static void main(String[] args) {
        //luu hình chữ nhật
        Rectangle re1 = new Rectangle(2, 5, "Tím");//Khai cha = new cha
        Square sq1 = new Square(3, "Đỏ");//khai con = new con
        Rectangle sq2 = new Square(5, "Cam");//Khai cha = new con; Rectangle => new Square
        //Nếu khai cha = new con thì:
        //thì object này có các quyền như cha và xài các method override
        //(sở hữu) các props của cha của con các method của cha và tất cả method của con
        //nhưng chỉ đc dùng các cái của cha và override của con chứ không được dùng cái của riêng thằng con
        //difting pointer
        //((Square)sq2).hehe();
        //Lưu
        Rectangle ds[] = new Rectangle[3];
        ds[0] = re1;
        ds[1] = sq1;
        ds[2] = sq2;
        //for each: mỗi || Iterator: tính khả lập
        //không cần điểm bắt đầu và kết thúc chỉ làm đến khi kết thúc
        for(Rectangle item : ds){
            item.paint();
        }
        
    }
    
}
