
package runtime;

import data.Triangle;
import data.RightTriangle;

public class Program {
    public static void main(String[] args) {
        //lưu trữ các hình tam giác(triangle)
        //tạo ra tam giác
        Triangle tr1 = new Triangle(4, 7, 9);
        
        //tạo ra tam giác vuông
        RightTriangle rtr1 = new RightTriangle(3, 4);
        
        //muốn lưu trữ thì phải cất vào mảng
        //tạo mảng chứa các hình tam giác
        Triangle triangleList[] = new Triangle[2];
        triangleList[0] = tr1;
        triangleList[1] = rtr1;
        // duyệt mảng các hình tam giác và kêu các hình in ra
        for(int i = 0; i <= triangleList.length - 1; i ++){
            triangleList[i].showInfor();
        }
    }
}
