
package data;
//tam giác vuông và tam giác
//      con          cha
//RightTriangle is a triangle
//mối quan hệ kế thừa là (is a)

//nếu như không nhận cha con thì sao
// thì mỗi class được mô tả độc lập vẫn tạo object bth
// nhưng không về chung 1 tập hợp(nhà | mảng)
// nhưng lưu trữ thì cần bỏ vào cung tập hợp
//Tại sao cần kế thừa | mục đích kế thừa là gì:
//làm sao để biết nó đang kế thừa
// -Thừa hưởng những gì người khác đã làm tốt rồi
// -Phát triển và mở rộng những gì người khác chưa làm | làm chưa tốt
// quy tắc: bất hiếu
//extends: Mở rộng

public class RightTriangle extends Triangle{
    //những prop mà cha em không có | prop đặc biệt của riêng em
    //trong trường hợp này righttriangle không có gì khác với cha cả
    //constructor
    public RightTriangle(double edgeA, double edgeB){
        super(edgeA, edgeB, Math.sqrt(edgeA * edgeA + edgeB * edgeB));
    }
    //super: bề trên -> new cha() => Triangle(edgeA, edgeB, edgeC)
    //super luôn là dòng lệnh đầu tiên trong constructor của con để đảm bảo rằng câu lệnh của cha luôn được chạy trước
    @Override
    public void showInfor(){
        String str = String.format("RightTriangle      |%5.2f|%5.2f|%5.2f|%5.2f|%5.2f",
                                   edgeA, edgeB, edgeC, getPerimeter(), getArea());
        System.out.println(str);
    }
}
