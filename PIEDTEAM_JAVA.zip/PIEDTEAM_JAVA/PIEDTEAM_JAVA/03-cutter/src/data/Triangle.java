
package data;
//class triangle là cái khuôn chuyên đúc ra các hình tam giác
public class Triangle {
    //props
    protected double edgeA;
    protected double edgeB;
    protected double edgeC;
    //private double perimeter = edgeA + edgeB + edgeC;
    //không nên tạo các thuộc tính như chu vi và diện tích
    // 1.Nếu tạo thì nó sẽ cần có getter và setter 
    //  vậy thì nếu tăng chu vi thì cạnh nào sẽ thay đổi ?
    // 2.Chu vi được cấu thành từ 3 cạnh:
    //   nếu tính chu vi rồi thay đổi 1 cạnh bất kỳ
    //   thì kết quả tính chu vi trước đó bị lỗi thời phải tính lại (cực)
    //   các thuộc tính có thể suy ra từ thuộc tính trước đó thì không nên lưu
    
    //method
    //    contructor
    
    public Triangle(double edgeA, double edgeB, double edgeC) {
        this.edgeA = edgeA;
        this.edgeB = edgeB;
        this.edgeC = edgeC;
    }

    //    getter
    public double getEdgeA() {
        return edgeA;
    }

    public double getEdgeB() {
        return edgeB;
    }

    public double getEdgeC() {
        return edgeC;
    }
    
    public double getPerimeter(){
        return edgeA + edgeB + edgeC;
    }
    
    public double getArea(){
        double p = this.getPerimeter()/2;
        return Math.sqrt(p * (p-edgeA) * (p-edgeB) * (p-edgeC));
    }
    //  show
    public void showInfor(){     
        String str = String.format("Triangle      |%5.2f|%5.2f|%5.2f|%5.2f|%5.2f",
                                   edgeA, edgeB, edgeC, getPerimeter(), getArea());
        System.out.println(str);
    }
}
