/*

 */
package data;

import java.util.Random;

public class Monkey extends Herbivore{
    public static final double RECEPTIVE = 70;
    //khỉ học kiểu bắt chước maximum 70%
    //contrucstor

    public Monkey(String name, int yob, double weigth) {
        super(name, yob, weigth);
    }

    public Monkey(String name, int yob, double weigth, String colorSaddle) {
        super(name, yob, weigth);
    }

    @Override
    public double study() {
        Random rd = new Random();
        return rd.nextDouble()* RECEPTIVE;//rd.nextDouble luôn trả dao động trong 0.0 đến 1.0
    }

    @Override
    public void showInfor() {
        String str = String.format("MONKEY|%-15s|%4d|%-6.2f|%5.2f", name, yob, weigth, study());
        System.out.println(str);
}
}
