/*
 là con của herbivore nó chỉ đc chứa những điểm riêng của nó còn những cái chung nó sẽ kế thừa
để khôi phục
 */
package data;

import java.util.Random;

public class Horse extends Herbivore{
    //props
    private String colorSaddle;
    public static final double RECEPTIVE = 30;//công khai nhưng không muốn ai sửa đổi nên biến nó thành hằng số và static
    //là biến nó thành giới hạn của giống loài
    //ngựa học hiểu hú hí maximum 30%
    //contrucstor

    public Horse(String name, int yob, double weigth, String colorSaddle) {
        super(name, yob, weigth);
        this.colorSaddle = colorSaddle;
    }

    @Override
    public double study(){
        Random rd = new Random();
        return rd.nextDouble()* RECEPTIVE;//rd.nextDouble luôn trả dao động trong 0.0 đến 1.0
    }

    @Override
    public void showInfor() {
        String str = String.format("HORSE|%-15s|%4d|%-6.2f|%5.2f|%s", name, yob, weigth, study(), colorSaddle);
        System.out.println(str);
    }



    
}
