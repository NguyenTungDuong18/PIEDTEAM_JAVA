
package runtime;

import data.Herbivore;
import data.Horse;
import data.Hunter;
import data.Monkey;
import java.util.ArrayList;

/*
Anh Điệp dạy học kèm người khác lấy 10 điểm thấy chán quá, dễ quá nên muốn tăng
độ khó hơn nữa, anh quyết định vào rừng mở lớp dạy khỉ, ngựa học lập trình và chinh
phục 10 điểm
Quản lí danh sách học sinh trong lớp thú vật này
*/
public class Program {
    public static void main(String[] args) {
        Monkey m1 = new Monkey("Rakiki", 1998, 210);//The Lion King
        Monkey m2 = new Monkey("Abu", 1994, 30);//Aladin
        Horse h1 = new Horse("Rarity", 2015, 9, "none");//Little pony
        Herbivore h2 = new Horse("Roach", 2019, 170, "Greay");//The witcher
        //tạo mảng xịn có thể co giãn và lưu danh sách
        ArrayList<Herbivore> stuList = new ArrayList<>();
        stuList.add(m1);
        stuList.add(m2);
        stuList.add(h1);
        stuList.add(h2);
        /*
        có 1 con vật gì đó không biết
        nhỏ bé mậc kín mít không biết là con gì nhưng ăn cỏ
        làm sao để lưu
        */
        //Dùng anonymous
        Herbivore xxx = new Herbivore("XXX", 2025, 4) {
            @Override
            public double study() {
                return 80;
            }
            
            @Override
            public void showInfor() {    
            String str = String.format("XXXXXX|%-15s|%4d|%-6.2f|%5.2f", name, yob, weigth, study());
            System.out.println(str);
            }
        };
        stuList.add(xxx);//lưu con XXX vào danh sách
        //lớp lại có thêm 1 bạn mới vào lớp
        //bạn này làm lớp nhốn nháo, sôi động
        //bác thợ săn
        Hunter hun1 = new Hunter("thợ săn vượn", 1999, 70, "nỏ");
        Hunter hun2 = new Hunter("Mắt diều hâu", 1999, 50, "Cung");
        //ko thể nhét hunter vào tro9ng danh sách được vì chúng nó quá khác nhau về mặt sinh học
        //nhưng phải tìm cách nhét vào vì lưu trữ
    }
    
}
