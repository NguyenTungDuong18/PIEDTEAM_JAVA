
 package runtime;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class Program {

    public static void main(String[] args) {
        //Collection là 1 interface ai mà có gốc của thg này đồng nghĩa là mảng mảng xin có khả năng co giãn
        //tập hợp những thg có tính co giãn
        playWithList();
        playWithQueue();
    }

    public static void playWithList() {
        /*
        Collection là bộ sưu tập các mảng xịn
        mảng thuộc Collection => mảng co giãn
         có thêm | xóa | duyệt | size()(trong đây không có code)
        List là con của collection
        có get và set
        ArrayList là người triển khai List
         có thêm | xóa | duyệt | size() | get | set (trong đây có code do là ng triển khai và khác nhau từng ng triển khai) 
         */

        //Tạo arrayPrimitive
        Integer arrIntPrimitive[] = new Integer[100];//Khai khống
        //không co giãn được do nằm ở stack bị 2 giá trị chặn 2 đầu
        //Array từ List thuộc Collection
        ArrayList <Integer> arrIntList = new ArrayList<>();
        //Lý thuyết chỉ cho lưu obj
        //ArrayList co giãn được do ArrayList được lưu ở Stack là 1 con trỏ là trỏ tới các obj được lưu ở vùng nhớ heap
        List<Integer> arrIntListV2 = new ArrayList<>();//khai cha new con
        
        //Nếu viết Collection <Integer> arr = new List/ArrayList <>() thì sẽ không có method get và set do đây là method của riêng thg con
        //thêm  .adđ(value) : thêm vào - Collection
        arrIntList.add(new Integer(3));
        arrIntList.add(new Integer(5));

        arrIntList.add(2);//auto-unboxing

        System.out.println(arrIntList);//[3  5  2]
        //không cần fore, vì nó toString()
        arrIntList.clear();//xóa hết - Collection (hàm clear nằm ở collection)

        //  .add(index, value): nhét vào vị trí nào đó
        arrIntList.add(0, 3);
        arrIntList.add(1, 5);
        arrIntList.add(1, 4);
        arrIntList.add(1, 4);

        System.out.println(arrIntList);//[3 4 5 4]

        //chuyển từ arrayPrimitive về thành List
        Integer arrDemo[] = {3, 5, 7};//đây là 1 array bth nên có bộ tool arrays
        ArrayList<Integer> arrList = new ArrayList<>(Arrays.asList(arrDemo));

        //chuyển từ list thành arrayPrimitive
        Integer[] numList = new Integer[arrList.size()];
        arrList.toArray(numList);
        // .get(index) lấy phần tử ở vị trí index
        // .set(index, value) thay thế value vào pt ở vị trí index
        //arrayList đang là [3, 5, 7]
        //swap sô 3 và 7
        Integer tmp = arrList.get(0);
        arrList.set(0, arrList.get(2));
        arrList.set(2, tmp);

        // .remove(index || pt): xóa và trả về pt bị xóa - Collection
        //Iterable: tính khả lập
        //Iterator: 1 obj định nghĩa 1 trình tự và giá trị có thể trả ra tiếp theo trước khi kết thúc việc gọi nó
        Iterator<Integer> it = arrList.iterator();// vì là collection là có iterable nên có iterator
        System.out.println(it.next());//7
        System.out.println(it.next());//5
        System.out.println(it.next());//3
        //System.out.println(it.next()); lỗi

        //.clone(): nhân bản | sao chép
        ArrayList<Integer> demoClone = arrList;
        demoClone.set(1, 9);
        System.out.println(arrList);
        //
        //Shallow copy: copy nông | sao chép nhưng không cắt được hết các dây tơ mơ rễ má
        ArrayList<Integer> demoClonee = (ArrayList) arrList.clone();//khi clone thành thg mới thì nó sẽ thành dạng list nên phải ép kiểu thành arraylist
        //và đây là wrapper nên có cơ chế auto unboxing -> lấy giá trị
        //deep copy: copy sâu | cắt đc hết dây tơ rễ má
    }

    public static void playWithQueue() {
        Queue<Integer> numList = new LinkedList<>();
        //thêm  .add(value)  .offer(value)
        
        numList.offer(3);
        numList.offer(1);
        numList.offer(5);
        numList.offer(4);
        
        //không có .add(index.value) vì không có nhét vào giữa
        System.out.println(numList);//[3, 1, 5, 4]
        
        //
        while(true){
            Integer customer = numList.poll();//lôi thằng đầu hàng ra
            if(customer == null) break;
            //xử lý cho customer đó
            System.out.println(customer);
        }
        System.out.println(numList);//[]
        
        //PriorityQueue: hàng đợi ưu tiên
        Queue<Integer> numListV3 = new PriorityQueue<>();
        numListV3.offer(3);
        numListV3.offer(5);
        numListV3.offer(1);
        numListV3.offer(9);
        numListV3.offer(2);
        System.out.println(numListV3);//[1 2 3 9 5] đảm bảo rằng 1 nửa bên trái bé hơn nửa bên phải
        numListV3.poll();//bóc được thg bé nhất
    }
}
//Deque: ArrayDeque nhẹ hơn linkedList nhưng ít chức năng hơn
//LinkedList