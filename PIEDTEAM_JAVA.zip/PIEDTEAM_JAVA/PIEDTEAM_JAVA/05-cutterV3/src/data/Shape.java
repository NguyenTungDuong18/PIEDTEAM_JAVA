
package data;
//class shape: là cha của mọi loại hình dạng
//cha của hình chữ nhật, hình tròn, hình tam giác, hình vuông
//Nếu là cha thì sao?
// thì nó chỉ được chứa những điểm chung của tất cả các con mà thôi

//Mục đích của kế thừa còn có nghĩa là: giúp khôi phục lại trạng thái như trước khi nhận cha
public abstract class Shape {
    //prop
    protected String owner;
    protected  String colour;
    //constructor

    public Shape(String owner, String colour) {
        this.owner = owner;
        this.colour = colour;
    }
   //getter

    public String getOwner() {
        return owner;
    }

    public String getColour() {
        return colour;
    }
    
    public abstract double getPerimeter();
    public abstract double getArea();
    public abstract void paint();
}
//tại sao phải lưu getP getA paint?
//vì đó là những gì các con đều có
//getA getP paint tại sao không có body
//vì không có công thức nào cả, nên mình không thể diền vào
//nếu mình điền vào thì tất cả các con phải xài cùng 1 công thức( và nó sai)
//Vậy getP getA đều là các khái niệm chưa định nghĩa được
//nên đều là abs method => Shape là abs class

//abs class là cái khuôn bị thủng không có khả năng đúc obj
//nó nhận 1 class khác làm con dể class đó vá(implement | làm rõ) các
//abs method(lỗ thủng| khái niệm trừu tượng) cho nó
// nếu class con k và được thì class đó thành abs clas