
package data;

public class Square extends Rectangle{

    
    //không có điểm riêng nào cả
    //constructor
    public Square(String owner, String colour, double edge) {
        super(owner, colour, edge, edge);
    }
   @Override
    public void paint() {
        String str = String.format("Square          |%-10s|%-10s|%5.2f|%5.2f|%5.2f", owner, colour, width, getPerimeter(), getArea());
         System.out.println(str);               
    }
}
