
package data;

public class Rectangle extends Shape{
    //liệt kê những prop riêng con
    protected double width;
    private double height;
    //constructor

    public Rectangle(String owner, String colour, double width, double height) {
        super(owner, colour);
        this.width = width;
        this.height = height;
    }
    //getter

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public double getPerimeter() {
        return (width + height) * 2;
    }

    @Override
    public double getArea() {
        return width * height;
    }

    @Override
    public void paint() {
        String str = String.format("Rectangle       |%-10s|%-10s|%5.2f|%5.2f|%5.2f|%5.2f", owner, colour, width, height, getPerimeter(), getArea());
         System.out.println(str);               
    }
    
}
