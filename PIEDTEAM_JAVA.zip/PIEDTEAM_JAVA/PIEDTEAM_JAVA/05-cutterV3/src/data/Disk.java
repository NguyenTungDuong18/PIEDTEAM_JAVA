
package data;

public class Disk extends Shape{
    //prop
    private double radius;
    public static final double PI = 3.14;
    //constructor
    public Disk(String owner, String colour, double radius){
        super(owner, colour);
        this.radius = radius;
    }
    //getter

    public double getRadius() {
        return radius;
    }
    @Override
    public double getPerimeter() {
        return PI*radius*2;
    }

    @Override
    public double getArea() {
        return PI*radius*radius;
    }

    @Override
    public void paint() {
        String str = String.format("Disk            |%-10s|%-10s|%5.2f|%5.2f|%5.2f", owner, colour, radius, getPerimeter(), getArea());
         System.out.println(str);               
    }
    
    
}
