
package data;

public class RightTriangle extends Triangle{
    //prop
    //constructor
    public RightTriangle(String owner, String colour, double edgeA, double edgeB){
        super(owner, colour, edgeA, edgeB, Math.sqrt(edgeA * edgeA + edgeB * edgeB));
    }
    //getter
    @Override
    public void paint(){
        String str = String.format("RightTriangle   |%-10s|%-10s|%5.2f|%5.2f|%5.2f|%5.2f|%5.2f"
            , owner, colour, edgeA, edgeB, Math.sqrt(edgeA * edgeA + edgeB * edgeB), getPerimeter(), getArea());
        System.out.println(str); 
    }

    
}
