
package data;

public class Triangle extends Shape{
    //prop
    protected double edgeA;
    protected double edgeB;
    private double edgeC;
    //constructor
    public Triangle(String owner, String colour, double edgeA, double edgeB, double edgeC){
        super(owner, colour);
        this.edgeA = edgeA;
        this.edgeB = edgeB;
        this.edgeC = edgeC;
    }
    //getter

    public double getEdgeA() {
        return edgeA;
    }

    public double getEdgeB() {
        return edgeB;
    }

    public double getEdgeC() {
        return edgeC;
    }

    @Override
    public double getPerimeter() {
        return edgeA + edgeB + edgeC;
    }

    @Override
    public double getArea() {
        double p = this.getPerimeter()/2;
        return Math.sqrt(p * (p-edgeA) * (p-edgeB) * (p-edgeC));
    }

    @Override
    public void paint() {
        String str =String.format("Triangle        |%-10s|%-10s|%5.2f|%5.2f|%5.2f|%5.2f|%5.2f", owner, colour, edgeA, edgeB, edgeC, getPerimeter(), getArea());
        System.out.println(str);
    }

    
    
}
