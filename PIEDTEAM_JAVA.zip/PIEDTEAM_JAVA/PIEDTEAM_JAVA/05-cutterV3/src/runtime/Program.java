
package runtime;
import data.Shape;

import data.Disk;

import data.Triangle;
import data.RightTriangle;

import data.Rectangle;
import data.Square;


public class Program {
    public static void main(String[] args) {
        //tạo mảng lưu các hình mình có
        Disk D = new Disk("D", "Red", 3);
        Triangle Tr1 = new Triangle("D", "Red", 2, 3, 4);
        RightTriangle Tr2 = new RightTriangle("D", "Red", 3, 4);
        Rectangle R = new Rectangle("D", "Red", 3 , 5);
        Square S = new Square("D", "Red", 4);
        
        Shape ds[] = new Shape[5];
        ds[0] = D;
        ds[1] = Tr1;
        ds[2] = Tr2;
        ds[3] = R;
        ds[4] = S;
        //in ra
        for (Shape item : ds) {
            item.paint();
        }
        //abs class không nhất thiết là cái khuôn bị thủng
        //abs class (là cái khuôn bị thủng khi và chỉ khi có abs method) bản thân nó thường không tạo obj mà sẽ đi tìm
        //1 class con(trung gian) class con này có nhiệm vụ kế thừa(extends) và
        //(implement) những lỗ thủng đó(abs method), nếu vá thành công thì class
        // con có thể tạo obj nếu không thành công thì class sẽ thành abs class
        
        //anonymous class: class vô danh 
        //là cách dùng abs class tạo obj
        //khi nào dùng: 
        //-Lười
        //-không biết đặt tên class con là gì | ngại
        //anonymous là kỹ thuật tạo obj thông qua khuôn
        //ưu điểm : nhanh
        //nhược điêm; không có tính tái sử dụng chỉ có thể copy
        //VD:có rất nhiều vật thể nhưng có 1 thg hơi khác biệt nên không
        //có nhu cầu tạo ra cái khuôn cho nó
        
        Shape p = new Shape("D", "7rpg") {
            @Override
            public double getPerimeter() {
                return 28;
            }
            
            @Override
            public double getArea() {
                return 33;
            }
            
            @Override
            public void paint() {
                String str = String.format("XXX     |%-10s|%-10s|%5.2f|%5.2f",
                        owner, colour, getPerimeter(), getArea());
                System.out.println(str);       
            }
        };
    }
}
//tại sao phải sử dụng abs method vì không muốn có tính áp đặt